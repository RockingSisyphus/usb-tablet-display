export const VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v11";
export const VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v4";

export class VibeFlowWorkflowError extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === undefined ? undefined : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
    if (details.sourceLocation) this.sourceLocation = details.sourceLocation;
  }
}

function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details,
  });
}

function throwIfAborted(signal, workflow, nodePath = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath,
    blockPath,
    cause: signal.reason,
  });
}

async function awaitWithAbort(value, signal, workflow, nodePath = "", blockPath = "") {
  // Cancellation is cooperative. Retain the actual operation through finally.
  return await value;
}

function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}

function dictionary() {
  return Object.create(null);
}

function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true,
  });
  return target;
}

function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type)
    ? schema.type
    : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string"
        && !(new RegExp(schema.pattern)).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object"
      ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}

function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left)
      && Array.isArray(right)
      && left.length === right.length
      && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length
    && leftKeys.every((key, index) =>
      key === rightKeys[index] && jsonEquals(left[key], right[key])
    );
}

function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}

function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}

function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}

function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}

function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError
    ? cause
    : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}

function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details,
  });
  root.kernelLog?.(event);
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause },
    );
  }
}

function normalizeOptions(workflow, options) {
  const raw = options === undefined ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  if (Object.hasOwn(raw,"detachedTimeoutMs")) throw vfError("VF_ASYNC_MIGRATION", "detachedTimeoutMs was removed; workflow waits for actual Node cleanup", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== undefined && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    statusStopping: raw.__vfStatusStopping,
    statusUpdate: raw.__vfStatusUpdate,
    kernelLog: raw.__vfKernelLog,
    capabilities: raw.capabilities ?? {},
    workflowInstanceId: raw.workflowInstanceId,
  };
}

function inputValues(workflow, inputs, input) {
  const values=inputs[__vfMultipleInputs]?.get(input.key);
  if(values)return values;

  return [inputs[input.key]];
}

function validatePublicInputs(workflow, inputs) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = inputValues(workflow,inputs,input).map(value=>validateJsonSchema(
      value,input.schema || workflow.schemas?.[input.type])).find(Boolean);
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow,
      );
    }
  }
}

function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}

function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: new Map(),
    activeEdges: new Set(),
    lastInputs: new Map(),
    nodeRuns: new Map(),
    stepCount: 0,
    initial,
  };
}

function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}

function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    for(const value of inputValues(state.workflow,state.initial,input)) {
      state.inboxes[nodeId].push(createEnvelope(input.key,input.type,value,'pipeline.input'));
    }
  }
}

function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type)
      .sort((a,b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) },
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) },
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}

function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}

function conditionMatches(condition, values) {
  if (!condition) return true;
  const equal = Object.is(values[condition.key], condition.literal);
  return condition.operator === "==" ? equal : !equal;
}

function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key
      && item.type === envelope.type
      && item.source_node === envelope.source_node,
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}

function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) },
    );
  }
  if (outputs && typeof outputs.then === "function") throw vfError("VF_COMPLETION_MISMATCH", "immediate node returned pending work", state.workflow);
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length
      || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) },
    );
  }
  for (const provider of node.provides) {
    const schema = state.workflow.schemas?.[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) },
      );
    }
  }
  return outputs;
}

function outputEnvelopes(node, outputs) {
  return node.provides.map((provider) =>
    createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}

function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key
        && item.type === envelope.type
        && item.source_node === envelope.source_node),
    );
    state.inboxes[targetId].push(envelope);
  }
}

function nodeContext(node, state, execution) {
  const allowed = dictionary();
  for (const requirement of node.capabilities || []) {
    const capability = state.root.capabilities[requirement.id];
    if (!capability) continue;
    const contextual = dictionary();
    const requested = new Set(requirement.operations || []);
    for (const [operationName, operation] of Object.entries(capability)) {
      if (requested.size && !requested.has(operationName)) continue;
      const grants = node.capability_policy?.capabilities;
      if (grants && Object.hasOwn(grants, requirement.id) && !grants[requirement.id].includes(operationName)) continue;
      setOwn(contextual, operationName, (input) => {
        if (execution && !execution.active) throw vfError("VF_NODE_CONTEXT_EXITED", "Node invocation has exited", state.workflow);
        return operation(input, {
        nodePath: nodePath(state, node.id),
        blockPath: formatBlockPath(state.path), signal: execution?.signal || state.root.signal, execution,
      });
      });
    }
    setOwn(allowed, requirement.id, Object.freeze(contextual));
  }
  return Object.freeze({
    signal: execution?.signal || state.root.signal,
    workflow: state.root.identity,
    capabilities: Object.freeze(allowed),
    updateInfo(info) { state.root.statusUpdate?.(info); },
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details,
      });
    },
  });
}

function invokeStaticImplementationSync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) },
    );
  }
  const execution = new NodeExecution(state.root.signal);
  try {
    const outputs = implementation(inputs, node.params, nodeContext(node, state, execution));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      cause.sourceLocation ||= {path:node.source?.ref || "", symbol:node.source?.export || ""};
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted && (cause?.name === "AbortError" || cause === state.root.signal.reason)) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause },
    );
  } finally {
    execution.exitSync();
  }
}

async function invokeStaticImplementationAsync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) },
    );
  }
  const execution = new NodeExecution(state.root.signal);
  let primaryFailure;
  try {
    const outputs = await awaitWithAbort(
      Promise.resolve().then(() =>
        implementation(inputs, node.params, nodeContext(node, state, execution))
      ),
      state.root.signal,
      state.workflow,
      nodePath(state, node.id),
      formatBlockPath(state.path),
    );
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      cause.sourceLocation ||= {path:node.source?.ref || "", symbol:node.source?.export || ""};
      primaryFailure = ensureErrorLocation(cause, state.workflow, state.path, node.id);
      throw primaryFailure;
    }
    if (state.root.signal?.aborted && (cause?.name === "AbortError" || cause === state.root.signal.reason)) {
      try { throwIfAborted(
        state.root.signal,
        state.workflow,
        nodePath(state, node.id),
        formatBlockPath(state.path),
      ); } catch(error) { primaryFailure=error; throw error; }
    }
    primaryFailure = vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      {
        nodePath: nodePath(state, node.id),
        blockPath: formatBlockPath(state.path),
        sourceLocation:{path:node.source?.ref || "",symbol:node.source?.export || ""},
        cause,
      },
    );
    throw primaryFailure;
  } finally {
    try { await execution.exit(); }
    catch(cleanup) {
      if(primaryFailure) (primaryFailure.cleanupErrors ||= []).push(cleanup);
      else throw cleanup;
    }
  }
}

function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id,
  });
  return inputs;
}

function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id,
  });
}

function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}

function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  const multiple = new Map();
  for (const input of inputSpecs) {
    const matches = items.filter((item) => item?.type === input.type);
    if (matches.length) {
      setOwn(initial, input.key, matches[0].value);
      multiple.set(input.key, matches.map(item => item.value));
    }
    else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow,
      );
    }
  }
  Object.defineProperty(initial, __vfMultipleInputs, {value: multiple});
  return initial;
}

function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) },
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}

function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}

function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}

function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = [...(state.candidates.get(spec.type) || [])]
      .sort((a,b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow,
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow,
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.workflow.schemas?.[spec.type];
    const values = spec.cardinality === "all"
      ? matches.map((item) => item.value)
      : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow,
        );
      }
    }
  }
  return output;
}

function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}

function consumeStaticActivation(node, state) {
  if (node.join_policy === 'all') {
    for (const route of state.workflow.routes) {
      if (route.schedule && route.target === node.id)
        state.activeEdges.delete(`${route.source}\0${route.target}`);
    }
  }
}
