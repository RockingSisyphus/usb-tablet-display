from __future__ import annotations

import json
import re
from typing import Any, Mapping

from vibeflow.targets.javascript.frontend.emission_protocol import EmissionWorkflow


_ABORT_SIGNAL_DECLARATION = """\
export interface VibeFlowAbortSignal {
  readonly aborted: boolean;
  readonly reason: unknown;
  readonly onabort: ((event: any) => unknown) | null;
  throwIfAborted(): void;
  addEventListener(type: string, listener: any, options?: any): void;
  removeEventListener(type: string, listener: any, options?: any): void;
  dispatchEvent(event: any): boolean;
}
"""


_DECLARATION_PREAMBLE = (
    """\
export type WorkflowTraceMode = "off" | "boundary" | "full";

"""
    + _ABORT_SIGNAL_DECLARATION
    + """
export interface WorkflowRunStatus {
  readonly state: "starting" | "running" | "stopping" | "succeeded" | "failed";
  readonly error: string | null;
  readonly updated_at: string;
  readonly info?: readonly Readonly<Record<string, unknown>>[];
}

export interface WorkflowTraceEvent {
  readonly kind: string;
  readonly workflowId: string;
  readonly nodeId?: string;
  readonly nodePath?: string;
  readonly path?: readonly string[];
  readonly [key: string]: unknown;
}

export class VibeFlowWorkflowError extends Error {
  readonly code: string;
  readonly workflowId: string;
  readonly nodePath: string;
  readonly blockPath: string;
}
"""
)


def declarations(workflow: EmissionWorkflow) -> str:
    input_lines: list[str] = []
    for item in workflow.inputs:
        optional = "" if item.required else "?"
        input_lines.append(
            f"  readonly {json.dumps(item.key)}{optional}: "
            f"{schema_to_typescript(item.schema)};"
        )
    output_lines: list[str] = []
    for item in workflow.outputs:
        optional = "?" if item.cardinality == "optional_one" else ""
        value_type = schema_to_typescript(item.schema)
        if item.cardinality == "all":
            value_type = f"readonly ({value_type})[]"
        output_lines.append(
            f"  readonly {json.dumps(item.alias)}{optional}: {value_type};"
        )
    from .templates import WORKFLOW_CONTEXT_DECLARATION
    session_lines = [WORKFLOW_CONTEXT_DECLARATION]
    contracts = ["export interface WorkflowInputs {", *input_lines, "}", "",
                 "export interface WorkflowOutputs {", *output_lines, "}"]
    named = getattr(workflow, "named_entry_contracts", ())
    if named:
        from .emission_view import bound_entry_view
        inputs, outputs = [], []
        for entry in named:
            selected = bound_entry_view(workflow, entry)
            input_type = "{ " + " ".join(f"readonly {json.dumps(item.key)}{'' if item.required else '?'}: {schema_to_typescript(item.schema)};" for item in selected.inputs) + " }"
            output_members = []
            for item in selected.outputs:
                value_type = schema_to_typescript(item.schema)
                if item.cardinality == "all":
                    value_type = f"readonly ({value_type})[]"
                output_members.append(f"readonly {json.dumps(item.alias)}{'?' if item.cardinality == 'optional_one' else ''}: {value_type};")
            inputs.append(f"  readonly {json.dumps(entry.name)}: {input_type};")
            outputs.append(f"  readonly {json.dumps(entry.name)}: {{ {' '.join(output_members)} }};")
        contracts = ["export interface WorkflowEntryInputs {", *inputs, "}",
            "export interface WorkflowEntryOutputs {", *outputs, "}",
            "export type WorkflowEntry = keyof WorkflowEntryInputs;",
            "export type WorkflowInputs = WorkflowEntryInputs[WorkflowEntry];",
            "export type WorkflowOutputs = WorkflowEntryOutputs[WorkflowEntry];"]
    lines = [
            _DECLARATION_PREAMBLE.rstrip(),
            "",
            *contracts,
            "",
            *session_lines,
            "",
            "export interface WorkflowRunOptions {",
            "  readonly workflowInstanceId?: string;",
            "  readonly entry?: WorkflowEntry;" if named else "  readonly entry?: string;",
            "  readonly signal?: VibeFlowAbortSignal;",
            '  readonly trace?: WorkflowTraceMode;',
            "  readonly onTrace?: (event: WorkflowTraceEvent) => void;",
            "  readonly workflowSession?: WorkflowSession;",
            "  readonly statusIntervalMs?: number;",
            "  readonly statusFile?: string;",
            "  readonly runDir?: string;",
            "  readonly onStatus?: (status: WorkflowRunStatus) => void;",
            "}",
            "",
            "export const VIBEFLOW_WORKFLOW_ABI: \"vibeflow.workflow.v12\";",
            "export const VIBEFLOW_PLUGIN_ABI: \"vibeflow.plugin.v5\";",
            _entry_declaration(workflow),
    ]

    lines.append("")
    lines.append("export const workflowDescriptor: Readonly<{workflow: {root: string; path: string; entry?: string} | null; entry_mode: 'sync' | 'async'; inputs: readonly unknown[]; outputs: readonly unknown[]; calls: readonly Readonly<{operation: 'invoke_sync' | 'call'; workflow: {root: string; path: string; entry?: string}; launch?: unknown}>[]; entries: Readonly<Record<string, unknown>>; default_entry: string}>;")
    return "\n".join(lines)


def _entry_declaration(workflow: EmissionWorkflow) -> str:
    named = getattr(workflow, "named_entry_contracts", ())
    if named:
        function = "runWorkflow" if workflow.entry_mode == "sync" else "runWorkflowAsync"
        result = "WorkflowEntryOutputs[E]" if workflow.entry_mode == "sync" else "Promise<WorkflowEntryOutputs[E]>"
        signatures = [f"export function {function}<E extends WorkflowEntry>(inputs: WorkflowEntryInputs[E], options: WorkflowRunOptions & {{readonly entry: E}}): {result};"]
        default = workflow.default_entry or (named[0].name if len(named) == 1 else None)
        if default is not None:
            key = json.dumps(default)
            result = f"WorkflowEntryOutputs[{key}]"
            if workflow.entry_mode == "async":
                result = f"Promise<{result}>"
            signatures.append(f"export function {function}(inputs: WorkflowEntryInputs[{key}], options?: WorkflowRunOptions & {{readonly entry?: {key}}}): {result};")
        return "\n".join(signatures)
    if workflow.entry_mode == "sync":
        return (
            "export function runWorkflow("
            "inputs: WorkflowInputs, options?: WorkflowRunOptions"
            "): WorkflowOutputs;"
        )
    return (
        "export function runWorkflowAsync("
        "inputs: WorkflowInputs, options?: WorkflowRunOptions"
        "): Promise<WorkflowOutputs>;"
    )







def _typescript_name(prefix: str, value: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", value)
    suffix = "".join(
        part[:1].upper() + part[1:] for part in parts
    ) or "Anonymous"
    if suffix[0].isdigit():
        suffix = f"_{suffix}"
    return f"{prefix}{suffix}"


def schema_to_typescript(schema: Mapping[str, Any] | None) -> str:
    if not schema:
        return "unknown"
    if "const" in schema:
        return _literal_type(schema["const"])
    enum = schema.get("enum")
    if isinstance(enum, list) and enum:
        return " | ".join(_literal_type(item) for item in enum)
    any_of = schema.get("anyOf", schema.get("oneOf"))
    if isinstance(any_of, list) and any_of:
        return " | ".join(
            schema_to_typescript(
                item if isinstance(item, Mapping) else None
            )
            for item in any_of
        )
    all_of = schema.get("allOf")
    if isinstance(all_of, list) and all_of:
        return " & ".join(
            schema_to_typescript(
                item if isinstance(item, Mapping) else None
            )
            for item in all_of
        )
    schema_type = schema.get("type")
    if isinstance(schema_type, list):
        return " | ".join(
            schema_to_typescript({**dict(schema), "type": item})
            for item in schema_type
        )
    if schema_type == "null":
        return "null"
    if schema_type == "boolean":
        return "boolean"
    if schema_type in {"integer", "number"}:
        return "number"
    if schema_type == "string":
        return "string"
    if schema_type == "array":
        item_schema = schema.get("items")
        item_type = schema_to_typescript(
            item_schema if isinstance(item_schema, Mapping) else None
        )
        return f"readonly ({item_type})[]"
    if schema_type == "object" or isinstance(
        schema.get("properties"),
        Mapping,
    ):
        return _object_type(schema)
    return "unknown"


def _object_type(schema: Mapping[str, Any]) -> str:
    properties = schema.get("properties", {})
    if not isinstance(properties, Mapping):
        return "Readonly<Record<string, unknown>>"
    required = {
        str(item)
        for item in schema.get("required", ())
        if isinstance(item, str)
    }
    members = []
    for key, child in properties.items():
        optional = "" if str(key) in required else "?"
        members.append(
            f"readonly {json.dumps(str(key))}{optional}: "
            f"{schema_to_typescript(child if isinstance(child, Mapping) else None)}"
        )
    if not members and schema.get("additionalProperties") is False:
        return "Readonly<Record<string, never>>"
    if schema.get("additionalProperties") is not False:
        members.append("readonly [key: string]: unknown")
    return "{ " + "; ".join(members) + " }"


def _literal_type(value: object) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, Mapping):
        if not value:
            return "Readonly<Record<string, never>>"
        members = [
            (
                f"readonly {json.dumps(str(key), ensure_ascii=False)}: "
                f"{_literal_type(item)}"
            )
            for key, item in sorted(
                value.items(),
                key=lambda entry: str(entry[0]),
            )
        ]
        return "{ " + "; ".join(members) + " }"
    if isinstance(value, (list, tuple)):
        return (
            "readonly ["
            + ", ".join(_literal_type(item) for item in value)
            + "]"
        )
    raise TypeError(
        f"JSON Schema literal is not JSON-compatible: "
        f"{type(value).__name__}"
    )


__all__ = ["declarations", "schema_to_typescript"]
