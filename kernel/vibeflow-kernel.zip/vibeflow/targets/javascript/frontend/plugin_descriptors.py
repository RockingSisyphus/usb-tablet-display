"""JavaScript lifecycle selection and native binding over shared descriptors."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from vibeflow.block_compiler import SourceRef
from vibeflow.core.descriptors import (
    PluginCatalog,
    PluginResolution,
    PluginSelection,
    PluginSelectionError,
    ResolvedPluginSelection,
    SourceLocator,
    resolve_plugin_selections,
)
from vibeflow.targets.javascript.frontend.bindings import (
    JavascriptPluginBinding,
)


PLUGIN_ERROR_CODES = {
    "PLUGIN.SELECTION.UNKNOWN": "VF_AOT_PLUGIN_UNKNOWN",
    "PLUGIN.SELECTION.DEPENDENCY": "VF_AOT_PLUGIN_UNKNOWN",
    "PLUGIN.SELECTION.TARGET": "VF_AOT_TARGET_IMPLEMENTATION_MISSING",
    "PLUGIN.SELECTION.CONTRACT": "VF_AOT_PLUGIN_CONFIG",
    "PLUGIN.SELECTION.CONFIG_SCHEMA": "VF_AOT_PLUGIN_CONFIG",
    "PLUGIN.SELECTION.TYPE": "VF_AOT_PLUGIN_KIND",
    "PLUGIN.SELECTION.CYCLE": "VF_AOT_PLUGIN_CYCLE",
    "PLUGIN.SELECTION.PLANNED_DEPENDENCY": (
        "VF_AOT_PLUGIN_PLANNED_DEPENDENCY"
    ),
}
PLUGIN_ABI_VERSION = "vibeflow.plugin.v5"


class JavascriptPluginError(ValueError):
    def __init__(
        self,
        code: str,
        message: str,
        plugin_id: str = "",
        *,
        details: Mapping[str, Any] | None = None,
    ) -> None:
        self.code = str(code)
        self.message = str(message)
        self.plugin_id = str(plugin_id)
        self.details = dict(details or {})
        super().__init__(self.message)

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


@dataclass(frozen=True)
class JavascriptPluginBindingPlan:
    """Static Target binding split by lifecycle role and Planned status."""

    compiler_plugins: tuple[JavascriptPluginBinding, ...] = ()
    runtime_plugins: tuple[JavascriptPluginBinding, ...] = ()
    planned_plugins: tuple[JavascriptPluginBinding, ...] = ()

    def __post_init__(self) -> None:
        groups = {
            "compiler": tuple(self.compiler_plugins),
            "runtime": tuple(self.runtime_plugins),
        }
        active_ids: list[str] = []
        for plugin_type, bindings in groups.items():
            if not all(isinstance(item, JavascriptPluginBinding) for item in bindings):
                raise TypeError(f"{plugin_type}_plugins contains an invalid binding")
            if any(
                item.plugin_type != plugin_type or item.status != "implemented"
                for item in bindings
            ):
                raise ValueError(
                    f"{plugin_type}_plugins must contain active {plugin_type} bindings"
                )
            object.__setattr__(self, f"{plugin_type}_plugins", bindings)
            active_ids.extend(item.id for item in bindings)
        planned = tuple(self.planned_plugins)
        if not all(isinstance(item, JavascriptPluginBinding) for item in planned):
            raise TypeError("planned_plugins contains an invalid binding")
        if any(item.status != "planned" for item in planned):
            raise ValueError("planned_plugins must contain only planned bindings")
        all_ids = (*active_ids, *(item.id for item in planned))
        if len(set(all_ids)) != len(all_ids):
            raise ValueError("JavaScript plugin binding ids must be unique")
        object.__setattr__(self, "planned_plugins", planned)

    def to_dict(self) -> dict[str, object]:
        return {
            "compiler": [item.to_dict() for item in self.compiler_plugins],
            "runtime": [item.to_dict() for item in self.runtime_plugins],
            "planned": [item.to_dict() for item in self.planned_plugins],
        }


def parse_javascript_plugin_selection(
    value: str | Mapping[str, Any],
) -> PluginSelection:
    """Parse one workflow plugin reference without resolving its source."""

    if isinstance(value, str):
        data: Mapping[str, Any] = {"id": value}
    elif isinstance(value, Mapping):
        data = value
    else:
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            "plugin selection must be a string id or object",
        )
    _check_fields(
        data,
        {
            "id",
            "scope",
            "status",
            "type",
            "targets",
            "dependencies",
            "config",
            "priority",
            "display_name",
            "description",
            "version",
        },
        field="plugin selection",
    )
    try:
        return PluginSelection(
            id=_required_string(data.get("id"), field="plugin selection.id"),
            status=str(data.get("status", "implemented")),
            plugin_type=str(data.get("type", "")),
            targets=_string_tuple(
                data.get("targets", ()),
                field="plugin selection.targets",
            ),
            dependencies=_string_tuple(
                data.get("dependencies", ()),
                field="plugin selection.dependencies",
            ),
            config=_mapping(
                data.get("config", {}),
                field="plugin selection.config",
            ),
            priority=data.get("priority"),
            display_name=_optional_string(data.get("display_name")),
            description=_optional_string(data.get("description")),
            version=_optional_string(data.get("version")),
        )
    except PluginSelectionError as exc:
        raise JavascriptPluginError(
            PLUGIN_ERROR_CODES.get(exc.code, "VF_AOT_PLUGIN_CONFIG"),
            exc.message,
            exc.plugin_id,
        ) from exc


def resolve_javascript_plugins(
    selections: Sequence[PluginSelection],
    *,
    catalog: PluginCatalog,
    target: str,
    entry_mode: str,
    project_root: Path | None = None,
    source_hashes: Mapping[str, str] | None = None,
) -> JavascriptPluginBindingPlan:
    """Resolve Core plugin declarations into static JS/TS factory bindings."""

    if entry_mode not in {"sync", "async"}:
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            "entry_mode must be sync or async",
        )
    try:
        resolution = resolve_plugin_selections(
            tuple(selections),
            catalog=catalog,
            target=target,
        )
    except PluginSelectionError as exc:
        raise JavascriptPluginError(
            PLUGIN_ERROR_CODES.get(exc.code, "VF_AOT_PLUGIN_CONFIG"),
            exc.message,
            exc.plugin_id,
        ) from exc
    return build_javascript_plugin_binding_plan(
        resolution,
        target=target,
        entry_mode=entry_mode,
        project_root=project_root,
        source_hashes=source_hashes,
        source_roots=catalog.source_roots,
    )


def build_javascript_plugin_binding_plan(
    resolution: PluginResolution,
    *,
    target: str,
    entry_mode: str,
    project_root: Path | None = None,
    source_hashes: Mapping[str, str] | None = None,
    source_roots: tuple[str, ...] = (),
) -> JavascriptPluginBindingPlan:
    if not isinstance(resolution, PluginResolution):
        raise TypeError("resolution must be a PluginResolution")
    hashes = source_hashes or {}
    active = tuple(
        _binding_from_resolved(
            item,
            target=target,
            entry_mode=entry_mode,
            project_root=project_root,
            source_hash=str(hashes.get(item.id, "")),
            source_roots=source_roots,
        )
        for item in resolution.active
    )
    planned = tuple(
        _binding_from_resolved(
            item,
            target=target,
            entry_mode=entry_mode,
            project_root=None,
            source_hash="",
        )
        for item in resolution.planned
    )
    return JavascriptPluginBindingPlan(
        compiler_plugins=tuple(
            item for item in active if item.plugin_type == "compiler"
        ),
        runtime_plugins=tuple(
            item for item in active if item.plugin_type == "runtime"
        ),
        planned_plugins=planned,
    )


def _binding_from_resolved(
    resolved: ResolvedPluginSelection,
    *,
    target: str,
    entry_mode: str,
    project_root: Path | None,
    source_roots: tuple[str, ...] = (),
    source_hash: str,
) -> JavascriptPluginBinding:
    implementation = resolved.implementation
    if resolved.status == "planned":
        return JavascriptPluginBinding(
            id=resolved.id,
            plugin_type=resolved.plugin_type,
            status="planned",
            target=target,
            implementation=None,
            config=resolved.config,
            priority=resolved.priority,
            dependencies=resolved.dependencies,
        )
    assert implementation is not None
    if implementation.language not in {"javascript", "typescript"}:
        raise JavascriptPluginError(
            "VF_AOT_TARGET_IMPLEMENTATION_MISSING",
            f"plugin '{resolved.id}' has no JavaScript implementation for '{target}'",
            resolved.id,
        )
    if resolved.plugin_type == "compiler" and (
        implementation.completion != "immediate"
    ):
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_FACTORY",
            f"{resolved.plugin_type} plugin '{resolved.id}' factory must be immediate",
            resolved.id,
        )
    if entry_mode == "sync" and implementation.completion == "suspend":
        raise JavascriptPluginError(
            "VF_ENTRY_MODE_PLUGIN_SUSPEND_IN_SYNC",
            f"sync workflow cannot use suspending plugin '{resolved.id}'",
            resolved.id,
        )
    source = implementation.source
    if not source.export:
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_FACTORY",
            f"plugin '{resolved.id}' implementation source.export is required",
            resolved.id,
        )
    source_ref = _javascript_source_ref(
        source,
        plugin_id=resolved.id,
        project_root=project_root,
        source_roots=source_roots,
    )
    return JavascriptPluginBinding(
        id=resolved.id,
        plugin_type=resolved.plugin_type,
        status="implemented",
        target=target,
        implementation=source_ref,
        config=resolved.config,
        completion=implementation.completion,
        priority=resolved.priority,
        dependencies=resolved.dependencies,
        external_packages=(
            resolved.descriptor.external_packages
            if resolved.descriptor is not None
            else ()
        ),
        language=implementation.language,
        source_hash=source_hash,
    )


def _javascript_source_ref(
    source: SourceLocator,
    *,
    plugin_id: str,
    project_root: Path | None,
    source_roots: tuple[str, ...] = (),
) -> SourceRef:
    ref = source.ref
    if source.kind == "file" and project_root is None:
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_SOURCE",
            f"plugin '{plugin_id}' file source requires project_root",
            plugin_id,
        )
    if source.kind == "file":
        assert project_root is not None
        root = Path(project_root).resolve()
        candidate = Path(ref)
        resolved = (
            candidate.resolve()
            if candidate.is_absolute()
            else (root / candidate).resolve()
        )
        ref = str(resolved)
    return SourceRef(kind=source.kind, ref=ref, export=source.export or "")


def _check_fields(
    value: Mapping[str, Any],
    allowed: set[str],
    *,
    field: str,
) -> None:
    unknown = sorted(str(key) for key in value if key not in allowed)
    if unknown:
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            f"{field} contains unknown fields: {unknown}",
        )


def _required_string(value: object, *, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            f"{field} must be a non-empty string",
        )
    return value.strip()


def _optional_string(value: object) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            "optional plugin metadata must be strings",
        )
    return value.strip()


def _string_tuple(value: object, *, field: str) -> tuple[str, ...]:
    if value in (None, ()):
        return ()
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            f"{field} must be a list of strings",
        )
    values = tuple(_required_string(item, field=field) for item in value)
    if len(set(values)) != len(values):
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            f"{field} contains duplicate values",
        )
    return values


def _mapping(value: object, *, field: str) -> Mapping[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise JavascriptPluginError(
            "VF_AOT_PLUGIN_CONFIG",
            f"{field} must be an object",
        )
    return value


__all__ = [
    "PLUGIN_ABI_VERSION",
    "JavascriptPluginBindingPlan",
    "JavascriptPluginError",
    "build_javascript_plugin_binding_plan",
    "parse_javascript_plugin_selection",
    "resolve_javascript_plugins",
]
