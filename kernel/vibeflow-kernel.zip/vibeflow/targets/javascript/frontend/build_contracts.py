from __future__ import annotations

import json
from typing import Any, Mapping

from vibeflow.targets.javascript.frontend.declarations import schema_to_typescript
from vibeflow.targets.javascript.frontend.emission_protocol import EmissionWorkflow
from vibeflow.targets.javascript.frontend.errors import AotBuildError
from vibeflow.targets.javascript.frontend.schema import (
    JavascriptJsonValueError,
    PortableSchemaError,
    validate_javascript_json_value,
    validate_portable_json_schema,
)
from vibeflow.targets.javascript.frontend.templates import ABORT_SIGNAL_DECLARATION


def validate_schema_subset(
    workflow: EmissionWorkflow,
) -> None:
    try:
        validate_javascript_json_value(
            workflow.to_dict(),
            path="workflow",
        )
        visited: set[int] = set()

        def visit(plan: EmissionWorkflow) -> None:
            if id(plan) in visited:
                return
            visited.add(id(plan))
            for type_key, schema in plan.schemas.items():
                validate_portable_json_schema(
                    schema,
                    path=f"schemas[{type_key!r}]",
                )
            for input_spec in plan.inputs:
                if input_spec.schema is not None:
                    validate_portable_json_schema(
                        input_spec.schema,
                        path=f"inputs[{input_spec.key!r}].schema",
                    )
            for output_spec in plan.outputs:
                if output_spec.schema is not None:
                    validate_portable_json_schema(
                        output_spec.schema,
                        path=f"outputs[{output_spec.alias!r}].schema",
                    )
            for node in plan.nodes:
                if node.subplan is not None:
                    visit(node.subplan)

        visit(workflow)
    except (JavascriptJsonValueError, PortableSchemaError) as exc:
        raise AotBuildError(
            getattr(exc, "code", "VF_AOT_SCHEMA_UNSUPPORTED"),
            str(exc),
        ) from exc


def node_contract_check(
    workflow: EmissionWorkflow,
) -> str:
    module_bindings: dict[str, str] = {}
    lines = [
        ABORT_SIGNAL_DECLARATION.rstrip(),
        (
            "type Envelope<T> = Readonly<{ key: string; type: string; "
            "value: T; source_node: string }>;"
        ),
    ]
    checks: list[str] = []
    check_index = 0
    capability_descriptors = _capability_descriptors(workflow)

    def visit(plan: EmissionWorkflow) -> None:
        nonlocal check_index
        for node in plan.nodes:
            if node.implementation is not None:
                module, exported = node.implementation.module, node.implementation.export
                namespace = module_bindings.setdefault(
                    module,
                    f"__vf_contract_module_{len(module_bindings)}",
                )
                input_members = []
                for requirement in node.requires:
                    value_type = schema_to_typescript(
                        plan.schemas.get(
                            requirement.type,
                            workflow.schemas.get(requirement.type),
                        )
                    )
                    if requirement.cardinality == "all":
                        envelope_type = f"readonly Envelope<{value_type}>[]"
                    elif requirement.cardinality == "optional_one":
                        envelope_type = f"Envelope<{value_type}> | null"
                    else:
                        envelope_type = f"Envelope<{value_type}>"
                    input_members.append(
                        f"readonly {json.dumps(requirement.type)}: {envelope_type}"
                    )
                implementation_metadata = _node_contract_metadata(node)
                output_members = []
                for provider in node.provides:
                    provider_schema = _provider_schema(
                        provider.type,
                        plan,
                        workflow,
                    )
                    output_members.append(
                        f"readonly {json.dumps(provider.key)}: "
                        f"{schema_to_typescript(provider_schema)}"
                    )
                input_type = (
                    "{ " + "; ".join(input_members) + " }"
                    if input_members
                    else "Readonly<Record<never, never>>"
                )
                output_type = (
                    "{ " + "; ".join(output_members) + " }"
                    if output_members
                    else "Readonly<Record<never, never>>"
                )
                params_type = _node_params_type(
                    node.params,
                    implementation_metadata,
                )
                context_type = _node_context_type(
                    node,
                    capability_descriptors=capability_descriptors,
                    workflow=workflow,
                )
                checks.extend(
                    [
                        (
                            f"const __vf_checked_{check_index}: ("
                            f"inputs: {input_type}, "
                            f"params: {params_type}, "
                            f"context: {context_type}"
                            f") => {output_type} | Promise<{output_type}> = "
                            f"{namespace}" + "".join(f"[{json.dumps(part)}]" for part in exported.split(".")) + ";"
                        ),
                        f"void __vf_checked_{check_index};",
                    ]
                )
                check_index += 1
            if node.subplan is not None:
                visit(node.subplan)

    visit(workflow)
    imports = [
        f"import * as {namespace} from {json.dumps(module)};"
        for module, namespace in module_bindings.items()
    ]
    return "\n".join([*imports, *lines, *checks, ""])


def runtime_plugin_contract_check(bindings: object) -> str:
    """Generate the narrow static ABI check required for runtime plugins."""

    plugins = tuple(getattr(bindings, "runtime_plugins", ()) or ())
    imports: list[str] = []
    checks: list[str] = [
        ABORT_SIGNAL_DECLARATION.rstrip(),
        "type Json = null | boolean | number | string | readonly Json[] | { readonly [key: string]: Json };",
        "type Context = Readonly<{ abiVersion: 'vibeflow.plugin.v4'; pluginId: string; pluginType: 'runtime'; target: 'node' | 'browser'; workflowId: string; config: Readonly<Record<string, Json>>; signal: VibeFlowAbortSignal }> ;",
        "type RuntimePlugin = Readonly<Record<string, unknown>>;",
        "type Factory = (context: Context) => RuntimePlugin;",
    ]
    for index, plugin in enumerate(plugins):
        namespace = f"__vf_runtime_plugin_contract_{index}"
        module = str(getattr(plugin, "module", ""))
        exported = str(getattr(plugin, "export", "createPlugin"))
        imports.append(f"import * as {namespace} from {json.dumps(module)};")
        checks.extend(
            [
                f"const __vf_runtime_factory_{index}: Factory = {namespace}" + "".join(f"[{json.dumps(part)}]" for part in exported.split(".")) + ";",
                f"void __vf_runtime_factory_{index};",
            ]
        )
    return "\n".join([*imports, *checks, ""])


def _node_contract_metadata(node: object) -> Mapping[str, Any]:
    value = getattr(node, "params_schema", None)
    return {"params_schema": value} if isinstance(value, Mapping) else {}


def _provider_schema(
    type_key: str,
    plan: EmissionWorkflow,
    workflow: EmissionWorkflow,
) -> Mapping[str, Any] | None:
    return plan.schemas.get(type_key, workflow.schemas.get(type_key))


def _node_params_type(
    params: Mapping[str, Any],
    implementation: Mapping[str, Any],
) -> str:
    raw_schema = implementation.get("params_schema")
    params_schema = raw_schema if isinstance(raw_schema, Mapping) else {}
    keys = sorted({str(key) for key in params} | {str(key) for key in params_schema})
    if not keys:
        return "Readonly<Record<never, never>>"
    members: list[str] = []
    for key in keys:
        schema = params_schema.get(key)
        if isinstance(schema, Mapping) and isinstance(schema.get("required"), bool):
            # A parameter's presence flag is metadata; JSON Schema's object
            # required field is a list of property names, including nested ones.
            schema = {name:value for name,value in schema.items() if name != "required"}
        value_type = (
            schema_to_typescript(schema)
            if isinstance(schema, Mapping)
            else _json_value_typescript(params.get(key))
        )
        optional = "" if key in params else "?"
        members.append(
            f"readonly {json.dumps(key)}{optional}: {value_type}"
        )
    return "{ " + "; ".join(members) + " }"


def _json_value_typescript(value: object) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float)):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, Mapping):
        members = [
            (
                f"readonly {json.dumps(str(key))}: "
                f"{_json_value_typescript(item)}"
            )
            for key, item in sorted(value.items(), key=lambda item: str(item[0]))
        ]
        return "{ " + "; ".join(members) + " }"
    if isinstance(value, (tuple, list)):
        item_types = sorted({_json_value_typescript(item) for item in value})
        item_type = " | ".join(item_types) if item_types else "never"
        return f"readonly ({item_type})[]"
    return "unknown"


def _capability_descriptors(
    workflow: EmissionWorkflow,
) -> Mapping[str, Any]:
    descriptors: dict[str, Any] = {}

    def visit(plan: EmissionWorkflow) -> None:
        for descriptor in plan.capabilities:
            descriptors.setdefault(descriptor.id, descriptor)
        for node in plan.nodes:
            if node.subplan is not None:
                visit(node.subplan)

    visit(workflow)
    return descriptors


def _node_context_type(
    node: Any,
    *,
    capability_descriptors: Mapping[str, Any],
    workflow: EmissionWorkflow,
) -> str:
    capability_members: list[str] = []
    for requirement in sorted(node.capabilities, key=lambda item: item.id):
        descriptor = capability_descriptors.get(requirement.id)
        operations = (
            tuple(sorted(requirement.operations))
            if requirement.operations
            else tuple(sorted(descriptor.operations if descriptor else ()))
        )
        operation_members: list[str] = []
        for operation_name in operations:
            operation = (
                descriptor.operations.get(operation_name)
                if descriptor is not None
                else None
            )
            input_schema = (
                workflow.schemas.get(operation.input_type)
                if operation is not None and operation.input_type
                else None
            )
            operation_output_schema = (
                workflow.schemas.get(operation.output_type)
                if operation is not None and operation.output_type
                else None
            )
            input_type = schema_to_typescript(input_schema)
            output_type = schema_to_typescript(operation_output_schema)
            return_type = (
                f"Promise<{output_type}>"
                if operation is not None
                and operation.completion == "suspend"
                else output_type
            )
            operation_members.append(
                (
                    f"readonly {json.dumps(operation_name)}: "
                    f"(input: {input_type}) => "
                    f"{return_type}"
                )
            )
        capability_members.append(
            (
                f"readonly {json.dumps(requirement.id)}: "
                "{ "
                + "; ".join(operation_members)
                + " }"
            )
        )
    capabilities_type = (
        "{ " + "; ".join(capability_members) + " }"
        if capability_members
        else "Readonly<Record<never, never>>"
    )
    return (
        "Readonly<{ "
        "signal?: VibeFlowAbortSignal; "
        "workflow: Readonly<{self(): {id: string}}>; "
        f"capabilities: {capabilities_type}; "
        "trace(kind: string, details?: Readonly<Record<string, unknown>>): void; "
        "updateInfo(info: readonly Readonly<Record<string, unknown>>[]): void"
        " }>"
    )


__all__ = [
    "node_contract_check",
    "runtime_plugin_contract_check",
    "validate_schema_subset",
]
