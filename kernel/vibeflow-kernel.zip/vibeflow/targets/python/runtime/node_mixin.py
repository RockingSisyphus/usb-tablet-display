from __future__ import annotations

import time
from vibeflow.targets.python.runtime.errors import attach_error
from pathlib import Path
from typing import Mapping

from vibeflow.targets.python.runtime.block_compiler import loop_block, nodeset_block
from vibeflow.targets.python.runtime.support.planned import load_stub_callable, resolve_stub_module_path, signature_is_run_stub
from vibeflow.targets.python.project.registry import NodeRegistryError
from vibeflow.targets.python.runtime.errors import PipelineRuntimeError, normalize_delegate_cli_system_exit
from vibeflow.targets.python.runtime.helpers import elapsed_ms
from vibeflow.targets.python.runtime.summaries import summarize_mapping

class RuntimeNodeMixin:
    def _execute_frame(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        self._signal.throw_if_aborted()
        with self._frame_execution_scope(frame):
            if frame.is_planned_stub:
                outputs = self._run_planned_stub_node(frame, inputs)
            elif frame.is_loop:
                if loop_block(self._plan, frame.id) is not None:
                    outputs = self._run_loop_block_node(frame, inputs)
                else:
                    outputs = self._run_loop_node(frame, inputs)
            elif frame.is_nodeset:
                if nodeset_block(self._plan, frame.id) is not None:
                    outputs = self._run_nodeset_block_node(frame, inputs)
                else:
                    outputs = self._run_nodeset_node(frame, inputs)
            else:
                outputs = self._run_pure_node(frame, inputs)
        return outputs


    def _run_planned_stub_node(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        started = time.perf_counter()
        try:
            self._call_runtime_plugins("before_node", frame.id, frame.definition_id, summarize_mapping(inputs))
            outputs = self._execute_planned_stub_outputs(frame, inputs)
            self._mark_node_run(frame.id)
            self._record_runtime_event(
                "planned_stub",
                frame.id,
                frame.definition_id,
                input_summary=summarize_mapping(inputs),
                output_summary=summarize_mapping(outputs),
                elapsed_ms=elapsed_ms(started),
                details={
                    "stub_module": frame.planned_stub_module,
                    "stub_path": frame.planned_stub_path,
                    "stub_sha256": frame.planned_stub_hash,
                    "input_types": list(inputs),
                    "output_keys": list(outputs),
                },
            )
            self._call_runtime_plugins("after_node", frame.id, frame.definition_id, summarize_mapping(outputs))
            return outputs
        except SystemExit as exc:
            if self.delegate_cli:
                try:
                    exit_signal = normalize_delegate_cli_system_exit(
                        exc, source=frame.id, effect_scope=frame.effect_scope
                    )
                except PipelineRuntimeError as denied:
                    failure = denied
                else:
                    raise exit_signal from exc
            else:
                failure = PipelineRuntimeError(
                    f"planned python_stub node '{frame.id}' attempted SystemExit outside delegate CLI mode"
                )
            self._record_failure_event(
                "node_failed",
                frame.id,
                frame.definition_id,
                input_summary=summarize_mapping(inputs),
                failure=str(failure),
                elapsed_ms=elapsed_ms(started),
            error=failure)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(failure), primary=failure)
            raise failure from exc
        except Exception as exc:
            self._record_failure_event("node_failed", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), failure=str(exc), elapsed_ms=elapsed_ms(started), error=exc)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(exc), primary=exc)
            raise

    def _run_pure_node(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        started = time.perf_counter()
        try:
            node = frame.node
            if node is None:
                raise PipelineRuntimeError(f"node '{frame.id}' has no bound callable")
            self._call_runtime_plugins("before_node", frame.id, frame.definition_id, summarize_mapping(inputs))
            outputs = self._execute_pure_outputs(frame, inputs)
            self._mark_node_run(frame.id)
            self._record_runtime_event("node", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), output_summary=summarize_mapping(outputs), elapsed_ms=elapsed_ms(started))
            self._call_runtime_plugins("after_node", frame.id, frame.definition_id, summarize_mapping(outputs))
            return outputs
        except SystemExit as exc:
            if not self.delegate_cli:
                failure = PipelineRuntimeError(
                    f"node '{frame.id}' attempted SystemExit outside delegate CLI mode"
                )
                self._record_failure_event(
                    "node_failed",
                    frame.id,
                    frame.definition_id,
                    input_summary=summarize_mapping(inputs),
                    failure=str(failure),
                    elapsed_ms=elapsed_ms(started),
                error=failure)
                self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(failure), primary=failure)
                raise failure from exc
            try:
                exit_signal = normalize_delegate_cli_system_exit(
                    exc, source=frame.id, effect_scope=frame.effect_scope
                )
            except PipelineRuntimeError as failure:
                self._record_failure_event(
                    "node_failed",
                    frame.id,
                    frame.definition_id,
                    input_summary=summarize_mapping(inputs),
                    failure=str(failure),
                    elapsed_ms=elapsed_ms(started),
                error=failure)
                self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(failure), primary=failure)
                raise failure from exc
            raise exit_signal from exc
        except NodeRegistryError as exc:
            failure = PipelineRuntimeError(str(exc))
            self._record_failure_event("node_failed", frame.id, frame.definition_id, failure=str(failure), elapsed_ms=elapsed_ms(started), error=failure)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(failure), primary=failure)
            raise failure from exc
        except Exception as exc:
            self._record_failure_event("node_failed", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), failure=str(exc), elapsed_ms=elapsed_ms(started), error=exc)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(exc), primary=exc)
            raise

    def _execute_pure_outputs(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        node = frame.node
        if node is None:
            raise PipelineRuntimeError(f"node '{frame.id}' has no bound callable")
        params = self.registry.merge_config(frame.definition_id, {
            key: value for key, value in frame.params.items() if key != "_global"
        })
        # Runtime globals retain their reference semantics; Node config is JSON.
        if "_global" in frame.params:
            params["_global"] = frame.params["_global"]
        from .lifecycle import NodeRunContext
        context = NodeRunContext(self, frame) if frame.accepts_context else None
        primary = None
        try:
            outputs = node.run_pure(inputs, params, context) if context else node.run_pure(inputs, params)
            from .completion import immediate
            outputs = immediate(outputs)
        except BaseException as exc:
            primary = exc
            self._signal.fail(exc)
            raise
        finally:
            if context:
                try:
                    context.close()
                except BaseException as cleanup:
                    if primary is None:
                        raise
                    primary.add_note(str(cleanup))
                    attach_error(primary, cleanup)
        self._signal.throw_if_aborted()
        return self._validate_outputs(frame, outputs)

    def _execute_planned_stub_outputs(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        if not self.runtime_options.allow_planned_stub:
            raise PipelineRuntimeError(f"planned python_stub node '{frame.id}' requires allow_planned_stub")
        if frame.is_nodeset:
            self._assert_planned_stub_nodeset_contract(frame)
        try:
            path = Path(frame.planned_stub_path) if frame.planned_stub_path else resolve_stub_module_path(frame.planned_stub_module, self.graph.project_root)
            run_stub = load_stub_callable(path)
        except Exception as exc:
            raise PipelineRuntimeError(f"planned python_stub '{frame.id}' failed to load stub: {exc}") from exc
        if not signature_is_run_stub(run_stub):
            raise PipelineRuntimeError(f"planned python_stub '{frame.id}' must expose run_stub(inputs, params)")
        outputs = run_stub(dict(inputs), dict(frame.params))
        return self._validate_outputs(frame, outputs, subject="planned python_stub")

    def _validate_outputs(self, frame: NodeFrame, outputs: object, *, subject: str = "node") -> Mapping[str, object]:
        if not isinstance(outputs, Mapping):
            raise PipelineRuntimeError(f"{subject} '{frame.id}' must return a mapping")
        actual = {str(key) for key in outputs}
        expected = set(frame.provide_keys)
        if actual != expected:
            raise PipelineRuntimeError(f"{subject} '{frame.id}' output keys must exactly match provides: expected {sorted(expected)}, got {sorted(actual)}")
        return {str(key): value for key, value in outputs.items()}

    def _assert_planned_stub_nodeset_contract(self, frame: NodeFrame) -> None:
        nodeset = self.graph.nodeset_types.get(frame.nodeset_type_id)
        if nodeset is None:
            raise PipelineRuntimeError(f"unknown planned python_stub nodeset: {frame.nodeset_type_id}")
        if set(frame.requires) != set(nodeset.requires):
            raise PipelineRuntimeError(f"planned python_stub nodeset instance '{frame.id}' requires must match nodeset '{nodeset.type_key}' requires")
        if set(frame.provides) != set(nodeset.provides):
            raise PipelineRuntimeError(f"planned python_stub nodeset instance '{frame.id}' provides must match nodeset '{nodeset.type_key}' provides")


__all__ = ["RuntimeNodeMixin"]
