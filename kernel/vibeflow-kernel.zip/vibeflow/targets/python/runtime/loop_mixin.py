from __future__ import annotations

import time
from typing import Mapping

from vibeflow.targets.python.runtime.block_compiler import graph_block, loop_block
from vibeflow.core.contracts import RunResult
from vibeflow.targets.python.runtime.errors import DelegateCliExit, PipelineRuntimeError
from vibeflow.targets.python.runtime.helpers import elapsed_ms
from vibeflow.targets.python.runtime.values import (
    _initial_loop_values,
    _loop_body_initial,
    _loop_outputs,
    _loop_should_stop,
    _update_loop_values,
)
from vibeflow.targets.python.runtime.summaries import summarize_mapping

class RuntimeLoopMixin:
    def _run_loop_node(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        started = time.perf_counter()
        self._record_runtime_event("loop_enter", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), details=frame.loop_spec.to_dict())
        self._call_runtime_plugins("before_node", frame.id, frame.definition_id, summarize_mapping(inputs))
        try:
            outputs = self._run_loop_outputs(frame, inputs)
            outputs = self._validate_outputs(frame, outputs, subject="loop node")
            self._mark_node_run(frame.id)
            self._record_runtime_event("loop_exit", frame.id, frame.definition_id, output_summary=summarize_mapping(outputs), elapsed_ms=elapsed_ms(started))
            self._call_runtime_plugins("after_node", frame.id, frame.definition_id, summarize_mapping(outputs))
            return outputs
        except Exception as exc:
            self._record_failure_event("loop_failed", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), failure=str(exc), elapsed_ms=elapsed_ms(started), error=exc)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(exc), primary=exc)
            raise

    def _run_loop_block_node(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        block = loop_block(self._plan, frame.id)
        if block is None:
            raise PipelineRuntimeError(f"loop node '{frame.id}' is not block compiled")
        started = time.perf_counter()
        self._record_runtime_event("loop_enter", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), details=frame.loop_spec.to_dict())
        self._record_runtime_event("loop_block_enter", frame.id, frame.definition_id, details={"block": block.name, "body": frame.loop_spec.body})
        self._call_runtime_plugins("before_node", frame.id, frame.definition_id, summarize_mapping(inputs))
        try:
            result = block.callable(self, inputs)
            outputs = self._validate_outputs(frame, result.outputs, subject="loop node")
            self._mark_node_run(frame.id)
            self._record_runtime_event("loop_block_exit", frame.id, frame.definition_id, output_summary=summarize_mapping(outputs), details={"block": block.name})
            self._record_runtime_event("loop_exit", frame.id, frame.definition_id, output_summary=summarize_mapping(outputs), elapsed_ms=elapsed_ms(started))
            self._call_runtime_plugins("after_node", frame.id, frame.definition_id, summarize_mapping(outputs))
            return outputs
        except Exception as exc:
            self._record_failure_event("loop_failed", frame.id, frame.definition_id, input_summary=summarize_mapping(inputs), failure=str(exc), elapsed_ms=elapsed_ms(started), error=exc)
            self._call_runtime_plugins("node_failed", frame.id, frame.definition_id, str(exc), primary=exc)
            raise

    def _run_loop_outputs(self, frame: NodeFrame, inputs: Mapping[str, object]) -> Mapping[str, object]:
        if frame.subplan is None:
            raise PipelineRuntimeError(f"loop node '{frame.id}' has no body execution plan")
        return self._run_while_loop(frame, inputs, require_block=False)

    def _execute_loop_block(self, node_name: str, inputs: object) -> Mapping[str, object]:
        frame = self._frames[node_name]
        if not isinstance(inputs, Mapping):
            raise PipelineRuntimeError(f"loop block '{node_name}' received non-mapping inputs")
        if frame.subplan is None or graph_block(frame.subplan) is None:
            raise PipelineRuntimeError(f"loop node '{frame.id}' body is not block compiled")
        return self._run_while_loop(frame, inputs, require_block=True)

    def _run_while_loop(self, frame: NodeFrame, inputs: Mapping[str, object], *, require_block: bool) -> Mapping[str, object]:
        spec = frame.loop_spec
        values = _initial_loop_values(inputs, spec.carry)
        runtime = self._nodeset_runtime(frame)
        iteration = 0
        while (
            spec.max_iterations is None
            or iteration < spec.max_iterations
        ):
            initial = _loop_body_initial(values, spec.carry)
            iteration_path = (frame.id, f"iter_{iteration}")
            result = self._run_loop_body_iteration(frame, runtime, initial, iteration_path, iteration)
            _update_loop_values(
                values,
                result,
                spec.carry,
                spec.collect,
                frame.subplan.graph.outputs,
            )
            iteration_count = iteration + 1
            values["loop.iterations"] = iteration_count
            if _loop_should_stop(frame, values, iteration_count):
                return _loop_outputs(frame, values)
            iteration += 1
        if not spec.stop_after and not spec.stop_when.source:
            return _loop_outputs(frame, values)
        raise PipelineRuntimeError(
            f"loop node '{frame.id}' exceeded "
            f"max_iterations={spec.max_iterations}"
        )

    def _run_loop_body_iteration(
        self,
        frame: NodeFrame,
        runtime: "PipelineRuntime",
        initial: Mapping[str, object],
        iteration_path: tuple[str, ...],
        iteration_index: int,
    ) -> RunResult:
        if self.runtime_options.trace == "full":
            self.trace.add_event(
                {
                    "kind": "loop_iteration",
                    "node": frame.id,
                    "type": frame.definition_id,
                    "details": {"iteration": iteration_index, "initial_keys": sorted(str(key) for key in initial)},
                },
                self._trace_event_path(iteration_path),
                self._trace_sink,
            )
        previous_sink = runtime._trace_sink
        previous_prefix = runtime._trace_path_prefix
        runtime._trace_sink = self._trace_sink
        runtime._trace_path_prefix = self._trace_event_path(iteration_path)
        try:
            result = runtime.run(initial)
        except DelegateCliExit:
            self.trace.merge_child(iteration_path, runtime.trace)
            raise
        except Exception:
            self.trace.merge_child(iteration_path, runtime.trace)
            raise
        finally:
            runtime._trace_sink = previous_sink
            runtime._trace_path_prefix = previous_prefix
        self.trace.merge_child(iteration_path, runtime.trace)
        return result


__all__ = ["RuntimeLoopMixin"]
