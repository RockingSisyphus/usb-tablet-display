from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from vibeflow.core.contracts import DataEnvelope, RunResult
from vibeflow.targets.python.runtime.errors import PipelineRuntimeError
from vibeflow.targets.python.runtime.trace import RuntimeTrace

@dataclass
class _RuntimeState:
    inboxes: dict[str, list[DataEnvelope]]
    result: RunResult = field(default_factory=RunResult)
    output_candidates: dict[str, list[DataEnvelope]] = field(default_factory=lambda: defaultdict(list))
    last_inputs: dict[str, dict[str, object]] = field(default_factory=dict)
    active_edges: set[tuple[str, str]] = field(default_factory=set)

class _NestedRuntimeFailure(PipelineRuntimeError):
    def __init__(self, message: str, child_trace: RuntimeTrace) -> None:
        super().__init__(message)
        self.child_trace = child_trace


__all__ = ["_NestedRuntimeFailure", "_RuntimeState"]
