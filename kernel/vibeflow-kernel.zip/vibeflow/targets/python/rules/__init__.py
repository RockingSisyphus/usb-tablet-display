"""python Rule declarations, assembled through the public contribution model."""
from vibeflow.targets.python.rules.node.definitions import source_rule_resources, implementation_resources
from vibeflow.targets.python.rules.source_quality import source_quality_resources, source_quality_handlers, source_quality_rule_defaults
from vibeflow.targets.python.rules.graph import workflow_topic_resources, workflow_topic_handlers, workflow_plan_resources


def builtin_rule_resources():
    from vibeflow.targets.python.rulesets import builtin_rulesets
    project_rules, _ = source_quality_resources()
    return ( *source_rule_resources(), *implementation_resources(), *project_rules,
        *workflow_topic_resources(), *workflow_plan_resources()), builtin_rulesets()


def builtin_declaration_origins():
    import inspect
    from vibeflow.core.descriptors.contributions import ResourceOrigin, ResourceOwner, resource_kind
    from vibeflow.targets.python.rulesets import standard_rulesets, source_quality_ruleset
    origins = {}
    project_rules, _ = source_quality_resources()
    for factory, resources in ((source_rule_resources, source_rule_resources()),
            (implementation_resources, implementation_resources()), (source_quality_resources, project_rules),
            (workflow_topic_resources, workflow_topic_resources()), (workflow_plan_resources, workflow_plan_resources()),
            (standard_rulesets, standard_rulesets()), (source_quality_ruleset, (source_quality_ruleset(),))):
        origin = ResourceOrigin(ResourceOwner("plugin", "vibeflow.core"), str(inspect.getsourcefile(factory)),
            inspect.getsourcelines(factory)[1], symbol=factory.__qualname__)
        for descriptor in resources:
            origins[(resource_kind(descriptor), descriptor.id)] = origin
    return origins
