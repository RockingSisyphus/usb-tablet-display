from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from vibeflow.core.flow import (
    GraphConfig,
    LOOP_DEFINITION_IDS,
    NodeCallSpec,
    NodesetTypeSpec,
    STATUS_PLANNED,
)
from vibeflow.core.findings import HealthFinding
from vibeflow.core.config.concurrency import business_config
from vibeflow.targets.python.project.registry import NodeRegistry, NodeRegistryError
from vibeflow.core.config.scope import ConfigScope, config_override_conflicts, node_invocation_scope, normalize_config_scope, scoped_node_params


@dataclass(frozen=True)
class _OverrideContext:
    caller_name: str
    nodeset: NodesetTypeSpec
    nodes_by_name: dict[str, NodeCallSpec]
    registry: NodeRegistry
    findings: list[HealthFinding]


@dataclass(frozen=True)
class _CompositeChild:
    kind: str
    type_key: str
    nodeset: NodesetTypeSpec | None


def current_node_configuration_findings(graph, *, registry, owner, global_config=None, overrides=None):
    """Validate only current calls; child tasks own their internal parameters."""
    findings = []
    scope = normalize_config_scope(global_config)
    overrides = overrides or {}
    for node in graph.nodes:
        if node.status == STATUS_PLANNED:
            continue
        child = _resolve_composite_child(node, graph)
        if child is not None:
            if child.nodeset is not None:
                _append_override_warning(findings, rule_id="CONFIG.GLOBAL_CONFIG.OVERRIDES_LOCAL",
                    object_id=node.id, message=f"global config overrides nodeset call config: {node.id}",
                    base=node.params, override=scope.values, allow=scope.allow_config_override,
                    details={"owner":owner, "nodeset":child.type_key})
                caller = node_invocation_scope({**node.params, **scope.values, **overrides.get(node.id, {})},
                    allow_config_override=node.allow_config_override)
                _append_override_warning(findings, rule_id="NODESET.CONFIG.OVERRIDES_GLOBAL_CONFIG",
                    object_id=node.id, message=f"nodeset call config overrides nodeset global_config: {node.id}",
                    base=normalize_config_scope(child.nodeset.global_config).values,
                    override=caller.values, allow=caller.allow_config_override,
                    details={"owner":owner, "nodeset":child.type_key})
                _validate_override_map(node.id, child.nodeset, node.node_config_overrides,
                    registry=registry, findings=findings)
            continue
        _append_node_config_finding(node, registry=registry, findings=findings, owner=owner,
            global_scope=scope, overrides=overrides or {})
    return tuple(findings)


def _append_node_config_finding(
    node: NodeCallSpec,
    *,
    registry: NodeRegistry,
    findings: list[HealthFinding],
    owner: str,
    global_scope: ConfigScope,
    overrides: Mapping[str, Mapping[str, object]],
) -> None:
    _append_override_warning(
        findings,
        rule_id="CONFIG.GLOBAL_CONFIG.OVERRIDES_LOCAL",
        object_id=node.id,
        message=f"global config overrides local node config: {node.id}",
        base=business_config(node.params),
        override=business_config(global_scope.values),
        allow=global_scope.allow_config_override,
        details={"owner": owner, "definition_id": node.definition_id},
    )
    try:
        config_spec = registry.get_config_spec(node.definition_id)
        scoped_params = scoped_node_params(node.params, global_scope, declared_keys=set(config_spec.schema))
        registry.merge_config(node.definition_id, {**scoped_params, **dict(overrides.get(node.id, {}))})
    except NodeRegistryError as exc:
        findings.append(
            _node_config_finding(
                "NODE.CONFIG.INVALID",
                node.id,
                str(exc),
                details={"definition_id": node.definition_id, "owner": owner, "params": dict(node.params), "global_config": dict(global_scope.values)},
            )
        )


def _validate_override_map(
    caller_name: str,
    nodeset: NodesetTypeSpec,
    overrides: Mapping[str, Mapping[str, object]],
    *,
    registry: NodeRegistry,
    findings: list[HealthFinding],
) -> None:
    nodes_by_name = {node.id: node for node in nodeset.graph.nodes}
    context = _OverrideContext(caller_name, nodeset, nodes_by_name, registry, findings)
    for path, value in overrides.items():
        _validate_override_path(str(path), dict(value), context)


def _validate_override_path(path: str, value: dict[str, object], context: _OverrideContext) -> None:
    head, sep, tail = path.partition(".")
    target = context.nodes_by_name.get(head)
    if target is None:
        context.findings.append(_node_config_finding("NODESET.CONFIG.UNKNOWN_NODE", context.caller_name, f"nodeset override references unknown node: {path}", details={"nodeset": context.nodeset.type_key, "path": path}))
        return
    if not sep:
        _validate_direct_override(context.caller_name, target, value, nodeset=context.nodeset, registry=context.registry, findings=context.findings)
        return
    child = _resolve_composite_child(target, context.nodeset.graph)
    if child is None:
        context.findings.append(
            _node_config_finding(
                "NODESET.CONFIG.INVALID_PATH",
                context.caller_name,
                f"override path passes through non-composite node: {path}",
                details={
                    "owner": f"nodeset:{context.nodeset.type_key}",
                    "nodeset": context.nodeset.type_key,
                    "path": path,
                    "node": target.id,
                    "definition_id": target.definition_id,
                    "composite_kind": "none",
                },
            )
        )
        return
    if child.nodeset is None:
        context.findings.append(
            _node_config_finding(
                "NODESET.CONFIG.INVALID_PATH",
                context.caller_name,
                f"override path passes through unresolved {child.kind} node: {path}",
                details=_override_path_details(context.nodeset, path, target, child),
            )
        )
        return
    _validate_override_map(context.caller_name, child.nodeset, {tail: value}, registry=context.registry, findings=context.findings)


def _validate_direct_override(
    caller_name: str,
    target: NodeCallSpec,
    value: dict[str, object],
    *,
    nodeset: NodesetTypeSpec,
    registry: NodeRegistry,
    findings: list[HealthFinding],
) -> None:
    child = _resolve_composite_child(target, nodeset.graph)
    if child is not None:
        findings.append(
            _node_config_finding(
                "NODESET.CONFIG.NESTED_PATH_REQUIRED",
                caller_name,
                f"override for nested {child.kind} must use a dotted path: {target.id}",
                details=_override_path_details(nodeset, target.id, target, child),
            )
        )
        return
    if target.status == STATUS_PLANNED:
        return
    try:
        registry.merge_config(target.definition_id, {**target.params, **value})
    except NodeRegistryError as exc:
        findings.append(_node_config_finding("NODESET.CONFIG.INVALID", caller_name, str(exc), details={"nodeset": nodeset.type_key, "node": target.id, "definition_id": target.definition_id}))


def _resolve_composite_child(target: NodeCallSpec, graph: GraphConfig) -> _CompositeChild | None:
    if target.definition_id in LOOP_DEFINITION_IDS:
        body = target.loop.body
        return _CompositeChild("loop", body, graph.nodeset_types.get(body))
    if target.definition_id in graph.nodeset_types:
        return _CompositeChild("nodeset", target.definition_id, graph.nodeset_types.get(target.definition_id))
    return None


def _override_path_details(nodeset: NodesetTypeSpec, path: str, target: NodeCallSpec, child: _CompositeChild) -> dict[str, object]:
    details: dict[str, object] = {
        "owner": f"nodeset:{nodeset.type_key}",
        "nodeset": nodeset.type_key,
        "path": path,
        "node": target.id,
        "definition_id": target.definition_id,
        "composite_kind": child.kind,
    }
    if child.kind == "loop":
        details["loop_body"] = child.type_key
    else:
        details["child_nodeset"] = child.type_key
    return details


def _append_override_warning(
    findings: list[HealthFinding],
    *,
    rule_id: str,
    object_id: str,
    message: str,
    base: Mapping[str, object],
    override: Mapping[str, object],
    allow: bool,
    details: Mapping[str, object],
) -> None:
    conflicts = config_override_conflicts(base, override)
    if allow or not conflicts:
        return
    findings.append(
        HealthFinding(
            rule_id=rule_id,
            severity="warning",
            object_type="node",
            object_id=object_id,
            failure_layer="config",
            message=message,
            suggested_fix_type="review_config",
            details={**dict(details), "conflicts": conflicts},
        )
    )


def _node_config_finding(
    rule_id: str,
    object_id: str,
    message: str,
    *,
    details: Mapping[str, object] | None = None,
) -> HealthFinding:
    return HealthFinding(
        rule_id=rule_id,
        severity="error",
        object_type="node",
        object_id=object_id,
        failure_layer="config",
        message=message,
        suggested_fix_type="fix_config",
        details=dict(details or {}),
    )

__all__ = ["current_node_configuration_findings"]
