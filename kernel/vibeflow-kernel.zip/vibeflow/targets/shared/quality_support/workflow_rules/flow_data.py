from __future__ import annotations

from typing import Mapping

from vibeflow.core.contracts import (
    CARDINALITY_EXACTLY_ONE,
    CARDINALITY_OPTIONAL_ONE,
)
from vibeflow.core.flow import STATUS_PLANNED
from vibeflow.core.constants import FLOW_KIND_TERMINAL
from vibeflow.core.findings import HealthFinding
from vibeflow.targets.shared.quality_support.workflow_rules.helpers import _data_finding, _parse_when, _provider_source_details
from vibeflow.targets.shared.quality_support.workflow_rules.runtime_inputs import (
    initial_input_nodes, append_runtime_requirement_findings, append_data_bypass_payload_findings,
)
from vibeflow.targets.shared.quality_support.workflow_rules.branch_paths import BranchPaths

def append_data_contract_warnings(
    graph,
    compiled,
    state,
    *,
    owner: str = "pipeline",
    runtime_flow_kinds: Mapping[str, str] | None = None,
) -> None:
    nodes_by_name = {node.id: node for node in graph.nodes}
    incoming = {node.id: set() for node in graph.nodes}
    outgoing = {node.id: set() for node in graph.nodes}
    for edge in compiled.resolved_transfer_edges:
        incoming.setdefault(edge.target, set()).add(edge.source)
        outgoing.setdefault(edge.source, set()).add(edge.target)
    condition_keys_by_source: dict[str, set[str]] = {node.id: set() for node in graph.nodes}
    for edge in compiled.resolved_transfer_edges:
        parsed = _parse_when(edge.when)
        if parsed is not None:
            condition_keys_by_source.setdefault(edge.source, set()).add(parsed[0])
    initial = initial_input_nodes(graph, compiled, runtime_flow_kinds)
    paths = BranchPaths(graph, compiled)
    for node in graph.nodes:
        if node.status == STATUS_PLANNED:
            continue
        _append_missing_provider_warnings(node, graph, nodes_by_name, incoming, state, initial, paths, owner=owner)
        _append_unconsumed_provider_warnings(node, graph, compiled, outgoing, condition_keys_by_source, state, owner=owner)
    append_runtime_requirement_findings(
        graph,
        compiled,
        nodes_by_name,
        state,
        owner=owner,
        runtime_flow_kinds=runtime_flow_kinds,
    )
    append_data_bypass_payload_findings(compiled, nodes_by_name, state, owner=owner)


def _append_missing_provider_warnings(node, graph, nodes_by_name, incoming, state, initial, paths, *, owner: str) -> None:
    direct = [nodes_by_name[name] for name in sorted(incoming.get(node.id, ())) if name in nodes_by_name]
    input_types = {item.type for item in graph.inputs} if node.id in initial else set()
    direct_source_details = _provider_source_details(direct)
    direct_provider_types = sorted({provider["type"] for source in direct_source_details for provider in source["provides"]})
    for requirement in node.requires:
        matches = [provider for parent in direct for provider in parent.provides if provider.type == requirement.type]
        if requirement.type in input_types:
            matches.append(None)
        base_details = {
            "owner": owner,
            "required_type": requirement.type,
            "required_cardinality": requirement.cardinality,
            "direct_sources": [source["node"] for source in direct_source_details],
            "direct_source_providers": direct_source_details,
            "available_provider_types": direct_provider_types,
            "entry_input_types": sorted(input_types),
        }
        if not matches:
            state.errors.append(
                _data_finding(
                    "GRAPH.DATA.MISSING_DIRECT_PROVIDER",
                    requirement.type,
                    f"node '{node.id}' requires type '{requirement.type}' but no direct incoming flow predecessor or entry input provides it",
                    node=node.id,
                    severity="error",
                    details=base_details,
                )
            )
            continue
        if requirement.cardinality in {CARDINALITY_EXACTLY_ONE, CARDINALITY_OPTIONAL_ONE} and len(matches) > 1:
            matched_sources = [_source_name(item, direct) for item in matches]
            if paths.sources_exclusive(node.id, matched_sources):
                continue
            finding = _data_finding(
                "GRAPH.DATA.TYPE_CARDINALITY_AMBIGUOUS",
                requirement.type,
                f"node '{node.id}' requires type '{requirement.type}' with {requirement.cardinality} but {len(matches)} direct sources may provide it",
                node=node.id,
                details={**base_details, "matched_sources": matched_sources},
            )
            if _sources_are_cyclic_alternatives(node.id, matched_sources, graph):
                state.warnings.append(finding)
            elif _direct_sources_are_unconditional(node.id, incoming.get(node.id, ()), graph):
                state.errors.append(_replace_severity(finding, "error"))
            else:
                state.warnings.append(finding)

def _append_unconsumed_provider_warnings(node, graph, compiled, outgoing, condition_keys_by_source, state, *, owner: str) -> None:
    nodes_by_name = {item.id: item for item in graph.nodes}
    downstream = [nodes_by_name[name] for name in sorted(outgoing.get(node.id, ())) if name in nodes_by_name]
    is_end = compiled.flow_kinds.get(node.id) == FLOW_KIND_TERMINAL and not outgoing.get(node.id)
    if is_end:
        return
    downstream_required_types = {
        child.id: sorted({requirement.type for requirement in child.requires})
        for child in downstream
    }
    exported_types = {output.type for output in graph.outputs}
    for provider in node.provides:
        if provider.key in condition_keys_by_source.get(node.id, set()):
            continue
        if provider.type in exported_types:
            continue
        if not any(provider.type == requirement.type for child in downstream for requirement in child.requires):
            state.warnings.append(
                _data_finding(
                    "GRAPH.DATA.UNCONSUMED_PROVIDER",
                    provider.key,
                    f"node '{node.id}' provides key '{provider.key}' type '{provider.type}' but no direct downstream flow successor requires that type",
                    node=node.id,
                    details={
                        "owner": owner,
                        "provider_key": provider.key,
                        "provider_type": provider.type,
                        "downstream_nodes": sorted(outgoing.get(node.id, ())),
                        "downstream_required_types": downstream_required_types,
                        "pipeline_output_types": sorted(exported_types),
                    },
                )
            )

def _direct_sources_are_unconditional(node_name: str, sources, graph) -> bool:
    relevant = [edge for edge in graph.edges if edge.target == node_name and edge.source in sources]
    return bool(relevant) and all(not edge.when for edge in relevant)

def _sources_are_cyclic_alternatives(node_name: str, sources: list[str], graph) -> bool:
    source_set = {source for source in sources if source != "pipeline.input"}
    if not source_set:
        return False
    outgoing: dict[str, list[str]] = {}
    for edge in graph.edges:
        outgoing.setdefault(edge.source, []).append(edge.target)
    reachable_from_node = _walk({node_name}, outgoing)
    return any(source in reachable_from_node and node_name in _walk({source}, outgoing) for source in source_set)

def _source_name(provider, direct) -> str:
    if provider is None:
        return "pipeline.input"
    for node in direct:
        if provider in node.provides:
            return node.id
    return str(getattr(provider, "key", provider))

def _replace_severity(finding: HealthFinding, severity: str) -> HealthFinding:
    return HealthFinding(
        rule_id=finding.rule_id,
        severity=severity,
        object_type=finding.object_type,
        object_id=finding.object_id,
        source_location=finding.source_location,
        rule_source=finding.rule_source,
        failure_layer=finding.failure_layer,
        message=finding.message,
        suggested_fix_type=finding.suggested_fix_type,
        details=finding.details,
    )

def _walk(starts: set[str], adjacency: dict[str, list[str]]) -> set[str]:
    seen = set(starts)
    queue = list(starts)
    while queue:
        node = queue.pop(0)
        for target in adjacency.get(node, ()):
            if target in seen:
                continue
            seen.add(target)
            queue.append(target)
    return seen


__all__ = ["append_data_contract_warnings"]
