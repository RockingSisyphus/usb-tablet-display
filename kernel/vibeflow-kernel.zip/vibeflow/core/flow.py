from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from vibeflow.core.constants import FLOW_KIND_PREDEFINED
from vibeflow.core.contracts import DataProvider, DataRequirement, PipelineInputSpec, PipelineOutputSpec
from vibeflow.core.planned import PlannedBehavior, blocking_planned_behavior
from vibeflow.core.workflows.entries import EntrySpec

STATUS_PLANNED = "planned"
STATUS_IMPLEMENTED = "implemented"
STATUSES = frozenset({STATUS_PLANNED, STATUS_IMPLEMENTED})
SIMILAR_TO_RELATIONSHIPS = frozenset({"variant", "copy"})
JOIN_POLICY_SAFE_ANY = "safe_any"
JOIN_POLICY_ANY_ACTIVE = "any_active"
JOIN_POLICY_ALL = "all"
JOIN_POLICIES = frozenset({JOIN_POLICY_SAFE_ANY, JOIN_POLICY_ANY_ACTIVE, JOIN_POLICY_ALL})
LOOP_WHILE_DEFINITION_ID = "vibeflow.loop.while"
LOOP_DEFINITION_IDS = frozenset({LOOP_WHILE_DEFINITION_ID})
ENTRY_MODE_SYNC = "sync"
ENTRY_MODE_ASYNC = "async"
ENTRY_MODES = frozenset({ENTRY_MODE_SYNC, ENTRY_MODE_ASYNC})


@dataclass(frozen=True)
class ExecutionLockSpec:
    """User-visible declaration for one Target execution-domain lock."""

    key: str

    def __post_init__(self) -> None:
        if not isinstance(self.key, str) or not self.key.strip():
            raise ValueError("execution lock key must be a non-empty string")
        normalized = self.key.strip()
        if normalized.startswith("vibeflow."):
            raise ValueError(
                "execution lock key uses reserved prefix 'vibeflow.'"
            )
        object.__setattr__(self, "key", normalized)

    def to_dict(self) -> dict[str, str]:
        return {"key": self.key}


@dataclass(frozen=True)
class NodeMetadata:
    display_name: str = ""
    description: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            "display_name": self.display_name,
            "description": self.description,
        }

@dataclass(frozen=True)
class NodeStyle:
    fill: str = ""
    stroke: str = ""
    text: str = ""
    shape: str = ""
    icon: str = ""

    def to_dict(self) -> dict[str, str]:
        return {key: value for key, value in (("fill", self.fill), ("stroke", self.stroke), ("text", self.text), ("shape", self.shape), ("icon", self.icon)) if value}

@dataclass(frozen=True)
class NodeSimilarity:
    node: str = ""
    relationship: str = ""
    reason: str = ""

    def to_dict(self) -> dict[str, str]:
        if not self.node:
            return {}
        return {
            "node": self.node,
            "relationship": self.relationship,
            "reason": self.reason,
        }

@dataclass(frozen=True)
class LoopCarrySpec:
    source: str
    target: str
    update: str

    def to_dict(self) -> dict[str, str]:
        return {"from": self.source, "as": self.target, "update": self.update}

@dataclass(frozen=True)
class LoopCollectSpec:
    source: str
    target: str
    mode: str = "all"

    def to_dict(self) -> dict[str, str]:
        return {"from": self.source, "as": self.target, "mode": self.mode}

@dataclass(frozen=True)
class LoopOutputSpec:
    source: str
    target: str

    def to_dict(self) -> dict[str, str]:
        return {"from": self.source, "as": self.target}

@dataclass(frozen=True)
class LoopStopWhenSpec:
    source: str = ""
    equals: bool = True

    def to_dict(self) -> dict[str, Any]:
        if not self.source:
            return {}
        return {"from": self.source, "equals": self.equals}

@dataclass(frozen=True)
class LoopSpec:
    body: str = ""
    max_iterations: int | None = 1000
    stop_after: int = 0
    stop_when: LoopStopWhenSpec = field(default_factory=LoopStopWhenSpec)
    carry: tuple[LoopCarrySpec, ...] = ()
    collect: tuple[LoopCollectSpec, ...] = ()
    outputs: tuple[LoopOutputSpec, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        if not self.body:
            return {}
        payload: dict[str, Any] = {
            "body": self.body,
            "max_iterations": self.max_iterations,
        }
        if self.stop_after:
            payload["stop_after"] = self.stop_after
        if self.stop_when.source:
            payload["stop_when"] = self.stop_when.to_dict()
        if self.carry:
            payload["carry"] = [item.to_dict() for item in self.carry]
        if self.collect:
            payload["collect"] = [item.to_dict() for item in self.collect]
        if self.outputs:
            payload["outputs"] = [item.to_dict() for item in self.outputs]
        return payload



@dataclass(frozen=True)
class NodeCallSpec:
    id: str
    definition_id: str
    requires: tuple[DataRequirement, ...] = ()
    provides: tuple[DataProvider, ...] = ()
    params: dict[str, Any] = field(default_factory=dict)
    metadata: NodeMetadata = field(default_factory=NodeMetadata)
    style: NodeStyle = field(default_factory=NodeStyle)
    similar_to: NodeSimilarity = field(default_factory=NodeSimilarity)
    join_policy: str = JOIN_POLICY_SAFE_ANY
    loop: LoopSpec = field(default_factory=LoopSpec)
    node_config_overrides: dict[str, dict[str, Any]] = field(default_factory=dict)
    allow_config_override: bool = False
    status: str = STATUS_IMPLEMENTED
    flow_kind: str = ""
    planned_behavior: PlannedBehavior = field(default_factory=blocking_planned_behavior)
    workflow_operations: tuple = ()
    execution_lock: ExecutionLockSpec | None = None
    rulesets: tuple | None = None


    def __post_init__(self) -> None:
        from vibeflow.core.rules.selection.models import selection_refs
        from vibeflow.core.config.concurrency import dispatch_limit
        from vibeflow.core.workflows.operations import normalize_operations
        object.__setattr__(self, "workflow_operations", normalize_operations(self.workflow_operations))
        dispatch_limit(self.params)
        object.__setattr__(self, "rulesets", selection_refs(self.rulesets, optional=True))
        if self.execution_lock is not None and not isinstance(
            self.execution_lock, ExecutionLockSpec
        ):
            raise ValueError(
                "node execution_lock must be an ExecutionLockSpec or None"
            )

@dataclass(frozen=True)
class EdgeSpec:
    source: str
    target: str
    when: str = ""
    schedule: bool | None = None
    transfer: bool | None = None

    @property
    def pair(self) -> tuple[str, str]:
        return (self.source, self.target)

@dataclass(frozen=True)
class NodesetTypeSpec:
    type_key: str
    display_name: str
    description: str
    requires: tuple[DataRequirement, ...]
    provides: tuple[DataProvider, ...]
    graph: "GraphConfig"
    global_config: dict[str, Any] = field(default_factory=dict)
    status: str = STATUS_IMPLEMENTED
    flow_kind: str = FLOW_KIND_PREDEFINED
    planned_behavior: PlannedBehavior = field(default_factory=blocking_planned_behavior)
    root_id: str = ""
    root_path: str = ""
    source_path: str = ""
    expand: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.expand, bool):
            raise ValueError("nodeset expand must be a boolean")

@dataclass(frozen=True)
class GraphConfig:
    nodes: tuple[NodeCallSpec, ...]
    edges: tuple[EdgeSpec, ...] = ()
    nodeset_types: dict[str, NodesetTypeSpec] = field(default_factory=dict)
    inputs: tuple[PipelineInputSpec, ...] = ()
    outputs: tuple[PipelineOutputSpec, ...] = ()
    max_steps: int = 1000
    entry_mode: str = ENTRY_MODE_SYNC
    project_root: str = ""
    root_id: str = ""
    root_path: str = ""
    source_path: str = ""
    execution_lock: ExecutionLockSpec | None = None
    rulesets: tuple | None = None
    entries: dict[str, EntrySpec] = field(default_factory=dict)
    default_entry: str = ""
    selected_entry: str = ""

    def __post_init__(self) -> None:
        from vibeflow.core.rules.selection.models import selection_refs
        object.__setattr__(self, "rulesets", selection_refs(self.rulesets, optional=True))
        if self.execution_lock is not None and not isinstance(
            self.execution_lock, ExecutionLockSpec
        ):
            raise ValueError(
                "graph execution_lock must be an ExecutionLockSpec or None"
            )

@dataclass
class GraphConfigError(ValueError):
    detail: str
    rule_id: str = ""

    def __str__(self) -> str:
        return f"Graph config error: {self.detail}"
