from __future__ import annotations
from vibeflow.core.rules.selection.models import selection_refs, selection_data


from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

from vibeflow.core.descriptors.json_values import freeze_mapping, thaw_json
from vibeflow.core.descriptors.models import JSON_SCHEMA_2020_12, DescriptorModelError, ImplementationDescriptor, _required_text, _string_tuple, _validate_implementation_coverage


PLUGIN_TYPES = frozenset({"compiler", "runtime"})


@dataclass(frozen=True)
class BaseLibDescriptor:
    id: str
    display_name: str
    description: str
    implementations: tuple[ImplementationDescriptor, ...]
    dependencies: tuple[str, ...] = ()
    external_packages: tuple[str, ...] = ()
    category: str = ""
    version: str = ""

    rulesets: tuple[str, ...] = ()
    presentation: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        from vibeflow.core.descriptors.presentation import normalize_presentation
        object.__setattr__(self, "presentation", normalize_presentation(self.presentation, field_name="base_lib.presentation"))
        object.__setattr__(self, "rulesets", selection_refs(self.rulesets, field_name="base_lib.rulesets"))
        object.__setattr__(
            self,
            "id",
            _required_text(self.id, field_name="base_lib.id"),
        )
        object.__setattr__(
            self,
            "display_name",
            _required_text(
                self.display_name,
                field_name="base_lib.display_name",
            ),
        )
        object.__setattr__(
            self,
            "description",
            _required_text(
                self.description,
                field_name="base_lib.description",
            ),
        )
        implementations = tuple(self.implementations)
        if not implementations:
            raise DescriptorModelError(
                "base_lib.implementations cannot be empty"
            )
        if not all(
            isinstance(item, ImplementationDescriptor)
            for item in implementations
        ):
            raise DescriptorModelError(
                "base_lib.implementations must contain ImplementationDescriptor values"
            )
        _validate_implementation_coverage(
            implementations,
            field_name="base_lib.implementations",
        )
        object.__setattr__(self, "implementations", implementations)
        object.__setattr__(
            self,
            "dependencies",
            _string_tuple(
                self.dependencies,
                field_name="base_lib.dependencies",
            ),
        )
        if self.id in self.dependencies:
            raise DescriptorModelError("base_lib cannot depend on itself")
        object.__setattr__(
            self,
            "external_packages",
            _string_tuple(
                self.external_packages,
                field_name="base_lib.external_packages",
            ),
        )
        object.__setattr__(self, "category", str(self.category or "").strip())
        object.__setattr__(self, "version", str(self.version or "").strip())

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": "base_lib",
            **({"presentation": thaw_json(self.presentation)} if self.presentation else {}),
            "rulesets": selection_data(self.rulesets),
            "id": self.id,
            "display_name": self.display_name,
            "description": self.description,
            "category": self.category,
            "version": self.version,
            "implementations": [
                item.to_dict() for item in self.implementations
            ],
            "dependencies": list(self.dependencies),
            "external_packages": list(self.external_packages),
        }


@dataclass(frozen=True)
class DataSchemaDescriptor:
    type_key: str
    schema: Mapping[str, Any]
    representation: str = "json"
    display_name: str = ""
    description: str = ""

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "type_key",
            _required_text(
                self.type_key,
                field_name="data_schema.type_key",
            ),
        )
        representation = _required_text(
            self.representation,
            field_name="data_schema.representation",
        )
        if representation != "json":
            raise DescriptorModelError(
                "data_schema.representation must be 'json'"
            )
        if not isinstance(self.schema, Mapping):
            raise DescriptorModelError("data_schema.schema must be an object")
        schema = dict(self.schema)
        dialect = schema.get("$schema")
        if dialect is not None and dialect != JSON_SCHEMA_2020_12:
            raise DescriptorModelError(
                "data_schema.schema.$schema must use JSON Schema draft 2020-12"
            )
        schema["$schema"] = JSON_SCHEMA_2020_12
        object.__setattr__(
            self,
            "schema",
            freeze_mapping(schema, field_name="data_schema.schema"),
        )
        object.__setattr__(self, "representation", representation)
        object.__setattr__(
            self,
            "display_name",
            str(self.display_name or "").strip(),
        )
        object.__setattr__(
            self,
            "description",
            str(self.description or "").strip(),
        )

    @property
    def id(self) -> str:
        return self.type_key

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": "data_schema",
            "type_key": self.type_key,
            "representation": self.representation,
            "display_name": self.display_name,
            "description": self.description,
            "schema": thaw_json(self.schema),
        }









@dataclass(frozen=True)
class PluginDescriptor:
    """Language-neutral metadata for one plugin implementation family.

    The descriptor contains only frozen values and source locators.  Loading a
    module, constructing a plugin, or retaining a Target-specific object is a
    Target responsibility.
    """

    id: str
    plugin_type: str
    targets: tuple[str, ...]
    implementations: tuple[ImplementationDescriptor, ...]
    dependencies: tuple[str, ...] = ()
    external_packages: tuple[str, ...] = ()
    config_schema: Mapping[str, Any] = field(default_factory=dict)
    config_defaults: Mapping[str, Any] = field(default_factory=dict)
    priority: int = 100
    display_name: str = ""
    category: str = ""
    description: str = ""
    version: str = ""

    rulesets: tuple[str, ...] = ()
    base_libs: tuple[str, ...] = ()
    presentation: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        from vibeflow.core.descriptors.presentation import normalize_presentation
        object.__setattr__(self, "presentation", normalize_presentation(self.presentation, field_name="plugin.presentation"))
        object.__setattr__(self, "base_libs", _string_tuple(self.base_libs, field_name="plugin.base_libs"))
        object.__setattr__(self, "rulesets", selection_refs(self.rulesets, field_name="plugin.rulesets"))
        plugin_id = _required_text(self.id, field_name="plugin.id")
        plugin_type = _required_text(
            self.plugin_type,
            field_name="plugin.type",
        ).lower()
        if plugin_type not in PLUGIN_TYPES:
            raise DescriptorModelError(
                f"plugin.type must be one of {sorted(PLUGIN_TYPES)}"
            )
        targets = _string_tuple(self.targets, field_name="plugin.targets")
        if not targets:
            raise DescriptorModelError("plugin.targets cannot be empty")
        unknown_targets = sorted(set(targets) - {"python", "node", "browser"})
        if unknown_targets:
            raise DescriptorModelError(
                "plugin.targets contains unsupported targets: "
                f"{unknown_targets}"
            )
        implementations = tuple(self.implementations)
        if not implementations:
            raise DescriptorModelError(
                "plugin.implementations cannot be empty"
            )
        if not all(
            isinstance(item, ImplementationDescriptor)
            for item in implementations
        ):
            raise DescriptorModelError(
                "plugin.implementations must contain "
                "ImplementationDescriptor values"
            )
        _validate_implementation_coverage(
            implementations,
            field_name="plugin.implementations",
        )
        implementation_targets = {
            target
            for implementation in implementations
            for target in implementation.targets
        }
        if set(targets) != implementation_targets:
            raise DescriptorModelError(
                "plugin.targets must exactly match implementation target coverage"
            )
        dependencies = _string_tuple(
            self.dependencies,
            field_name="plugin.dependencies",
        )
        if plugin_id in dependencies:
            raise DescriptorModelError("plugin cannot depend on itself")
        if isinstance(self.priority, bool) or not isinstance(self.priority, int):
            raise DescriptorModelError("plugin.priority must be an integer")
        object.__setattr__(self, "id", plugin_id)
        object.__setattr__(self, "plugin_type", plugin_type)
        object.__setattr__(self, "targets", targets)
        object.__setattr__(self, "implementations", implementations)
        object.__setattr__(self, "dependencies", dependencies)
        object.__setattr__(
            self,
            "external_packages",
            _string_tuple(
                self.external_packages,
                field_name="plugin.external_packages",
            ),
        )
        object.__setattr__(
            self,
            "config_schema",
            freeze_mapping(
                self.config_schema,
                field_name="plugin.config_schema",
            ),
        )
        object.__setattr__(
            self,
            "config_defaults",
            freeze_mapping(
                self.config_defaults,
                field_name="plugin.config_defaults",
            ),
        )
        object.__setattr__(self, "display_name", str(self.display_name or "").strip())
        object.__setattr__(self, "category", str(self.category or "").strip())
        object.__setattr__(self, "description", str(self.description or "").strip())
        object.__setattr__(self, "version", str(self.version or "").strip())

    def to_dict(self) -> dict[str, object]:
        return {
            "kind": "plugin",
            **({"presentation": thaw_json(self.presentation)} if self.presentation else {}),
            **({"base_libs": list(self.base_libs)} if self.base_libs else {}),
            "rulesets": selection_data(self.rulesets),
            "id": self.id,
            "type": self.plugin_type,
            "targets": list(self.targets),
            "display_name": self.display_name,
            "category": self.category,
            "description": self.description,
            "version": self.version,
            "priority": self.priority,
            "implementations": [
                item.to_dict() for item in self.implementations
            ],
            "dependencies": list(self.dependencies),
            "external_packages": list(self.external_packages),
            "config": {
                "schema": thaw_json(self.config_schema),
                "defaults": thaw_json(self.config_defaults),
            },
        }
