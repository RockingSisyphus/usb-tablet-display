from __future__ import annotations
from vibeflow.tooling.project.diagnostics import workspace_or_report

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Mapping, Sequence

from vibeflow.tooling.application.python.run_directory import parse_run_id_argument


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="vibeflow")
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate", help="validate topology config structure and compile graph")
    validate.add_argument("--config", required=True)
    validate.add_argument("--workspace", required=False, help="workspace vibeflow_config.jsonc path")
    validate.add_argument("--json", action="store_true", help="emit full HealthReport JSON")

    inspect_node = sub.add_parser("inspect-node", help="inspect a node class and static purity findings")
    inspect_node.add_argument("--config", required=True, help="workflow selecting the resource plugins")
    inspect_node.add_argument("--node-id", required=True, dest="node_id")
    inspect_node.add_argument("--module", required=False, help="Python file containing the node class")
    inspect_node.add_argument("--class", required=False, dest="class_name", help="Class name to inspect inside --module")

    inspect_config = sub.add_parser("inspect-config", help="inspect parsed topology config and compiled edges")
    inspect_config.add_argument("--config", required=True)
    inspect_config.add_argument("--workspace", required=False, help="workspace vibeflow_config.jsonc path")

    mermaid = sub.add_parser("export-mermaid", help="export topology config to Mermaid flowchart")
    mermaid.add_argument("--config", required=True)
    mermaid.add_argument("--workspace", required=False, help="workspace vibeflow_config.jsonc path")
    mermaid.add_argument("--output", required=False)
    mermaid.add_argument("--expand-nodesets", dest="expand_nodesets", action="store_true")
    mermaid.add_argument("--collapse-nodeset_types", dest="expand_nodesets", action="store_false")
    mermaid.add_argument("--hide-contract", action="store_true")
    mermaid.add_argument("--hide-semantics", action="store_true")
    mermaid.add_argument(
        "--mermaid-layout",
        choices=("default", "review-columns"),
        default="default",
        help="Mermaid layout strategy: default inline layout or review-columns audit layout",
    )
    mermaid.set_defaults(expand_nodesets=False)

    architecture = sub.add_parser("export-architecture", help="export a generated non-executable architecture review document")
    architecture.add_argument("--config", required=True)
    architecture.add_argument("--workspace", required=False, help="workspace vibeflow_config.jsonc path")
    architecture.add_argument("--output", required=False)
    architecture.add_argument("--check", action="store_true", help="check that --output is canonical and current without writing it")

    run = sub.add_parser("run", help="run topology config after mandatory health checks")
    run.add_argument("--config", required=True)
    run.add_argument("--workspace", required=False, help="workspace vibeflow_config.jsonc path")
    run.add_argument("--input", required=False, help="optional JSON object file for initial context")
    run.add_argument("--entry", help="named workflow entry")
    run.add_argument("--preview-root", help="override offline preview directory")
    run.add_argument("--run-root", required=False, help="directory where run artifacts are created")
    run.add_argument(
        "--run-id",
        required=False,
        type=parse_run_id_argument,
        help="optional deterministic run id for tests or controlled runs",
    )
    _add_runtime_options(run)

    from vibeflow.tooling.application.python.cli.delegate_cli import add_delegate_cli_parser

    add_delegate_cli_parser(sub, _add_runtime_options)

    from vibeflow.tooling.application.python.cli.review import add_review_parser

    add_review_parser(sub)

    from vibeflow.tooling.application.project_quality import add_quality_parser

    add_quality_parser(sub)
    from vibeflow.tooling.application.python.cli.build import add_build_parser
    add_build_parser(sub)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    raw_args = list(sys.argv[1:] if argv is None else argv)
    if raw_args and raw_args[0] == "delegate-cli":
        if "--" in raw_args:
            separator = raw_args.index("--")
            kernel_args = raw_args[:separator]
            delegated_args = raw_args[separator + 1 :]
        else:
            kernel_args = raw_args
            delegated_args = []
        args, unknown = parser.parse_known_args(kernel_args)
        args.delegate_argv = [*unknown, *delegated_args]
    else:
        args = parser.parse_args(raw_args)
    handlers = {
        "validate": _handle_validate,
        "inspect-node": _handle_inspect_node,
        "inspect-config": _handle_inspect_config,
        "export-architecture": _handle_export_architecture,
        "export-mermaid": _handle_export_mermaid,
        "review": _handle_review,
        "run": _handle_run,
        "build": _handle_build,
        "delegate-cli": _handle_delegate_cli,
        "quality-check": _handle_quality_check,
    }
    handler = handlers.get(args.command)
    if handler is None:
        parser.error(f"unknown command: {args.command}")
        return 2
    return handler(args)


def _handle_validate(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.result_scope import add_result_scope, format_result_scope
    from vibeflow.tooling.application.python.cli.config import validate_config_path
    from vibeflow.tooling.application.python.reports import format_finding_text

    if getattr(args, "workspace", None):
        from vibeflow.core.findings import HealthReport
        from vibeflow.tooling.application.python.workspace_service import validate_workspace_config_path

        workspace = workspace_or_report(Path(args.workspace))
        if isinstance(workspace, HealthReport):
            report = workspace
        else:
            report = validate_workspace_config_path(Path(args.config), workspace=workspace)
    else:
        report = validate_config_path(Path(args.config))
    payload = add_result_scope(
        report.to_dict(),
        "vibeflow_structure",
        checked_ids=None if report.status in {"PASS", "CONCERNS"} else (),
    )
    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(format_result_scope(payload))
        for finding in (*report.errors, *report.warnings):
            print(format_finding_text(finding))
    return 0 if report.status in {"PASS", "CONCERNS"} else 1


def _handle_inspect_node(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.python.cli.node import inspect_node_payload

    payload, status = inspect_node_payload(
        node_id=args.node_id, config_path=Path(args.config),
        module_path=Path(args.module) if args.module else None,
        class_name=args.class_name,
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return status


def _handle_inspect_config(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.python.cli.config import inspect_config_payload

    if getattr(args, "workspace", None):
        payload, status = _inspect_workspace_config_payload(Path(args.config), Path(args.workspace))
    else:
        payload, status = inspect_config_payload(Path(args.config))
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return status


def _handle_export_mermaid(args: argparse.Namespace) -> int:
    return _handle_export_graph(args, export_kind="mermaid")


def _handle_export_architecture(args: argparse.Namespace) -> int:
    return _handle_export_graph(args, export_kind="architecture")


def _handle_review(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.python.cli.review import handle_review

    return handle_review(args)


def _handle_export_graph(args: argparse.Namespace, *, export_kind: str) -> int:
    from vibeflow.tooling.application.python.cli.export import handle_export_graph

    return handle_export_graph(args, export_kind=export_kind)


from vibeflow.tooling.application.python.run_observation import observed_cli_run, print_run_report


@observed_cli_run
def _handle_run(args: argparse.Namespace) -> int:
    from vibeflow.targets.python.project.registry import NodeRegistry
    from vibeflow.tooling.application.python.project.declarations import default_python_registry
    from vibeflow.tooling.application.python.execution import (CheckedRunError)

    try:
        initial = _load_initial_input(Path(args.input)) if args.input else {}
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print_run_report({"status": "ERROR", "error": str(exc)})
        return 1
    try:
        from vibeflow.core.findings import HealthReport
        from vibeflow.tooling.project.workspace_loader import load_project_workspace
        from vibeflow.tooling.application.python.cli.execution import dispatch_workspace as run_workspace_checked
        workspace = workspace_or_report(Path(args.workspace)) if args.workspace else workspace_or_report(Path(args.config), registered_source=True)
        if isinstance(workspace, HealthReport):
            print_run_report({"status": workspace.status, "error": "workspace load failed", "health": workspace.to_dict()})
            return 1
        result = run_workspace_checked(Path(args.config), workspace=workspace, initial=initial,
            run_root=Path(args.run_root) if args.run_root else None, run_id=args.run_id,
            runtime_options=_runtime_options_from_args(args),
            _prepared_run_dir=getattr(args, "_prepared_run_dir", None),
            preview_root=getattr(args, "preview_root", None), entry=getattr(args, "entry", None))
    except CheckedRunError as exc:
        from vibeflow.tooling.application.python.execution import (_checked_run_error_payload)
        print_run_report(_checked_run_error_payload(exc))
        return 1
    from vibeflow.tooling.application.python.execution import (_write_execution_report)
    print_run_report(_write_execution_report(result))
    return 0


@observed_cli_run
def _handle_delegate_cli(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.python.cli.delegate_cli import handle_delegate_cli

    return handle_delegate_cli(args)


def _handle_quality_check(args: argparse.Namespace) -> int:
    from vibeflow.tooling.application.project_quality import handle_quality_check

    return handle_quality_check(args)


def _inspect_workspace_config_payload(config_path: Path, workspace_path: Path) -> tuple[dict[str, object], int]:
    from vibeflow.core.contracts import providers_to_dicts, requirements_to_dicts
    from vibeflow.core.findings import HealthReport
    from vibeflow.tooling.application.python.cli.config import _inspect_workspace_graph

    workspace = workspace_or_report(workspace_path)
    if isinstance(workspace, HealthReport):
        return {"health": workspace.to_dict()}, 1
    prepared = _inspect_workspace_graph(config_path, workspace=workspace)
    report = prepared if isinstance(prepared, HealthReport) else prepared.health
    payload: dict[str, object] = {"health": report.to_dict(), "workspace": report.info.get("workspace", {})}
    if report.status not in {"PASS", "CONCERNS"}:
        return payload, 1
    document, graph, compiled, resources = prepared.document, prepared.graph, prepared.compiled, prepared.resources
    payload["config"] = {
        "inputs": providers_to_dicts(graph.inputs),
        "outputs": requirements_to_dicts(graph.outputs),
        "nodes": [
            {
                "id": node.id,
                "definition_id": node.definition_id,
                "requires": requirements_to_dicts(node.requires),
                "provides": providers_to_dicts(node.provides),
                "status": node.status,
                "planned_behavior": node.planned_behavior.to_dict(),
                "similar_to": node.similar_to.to_dict(),
                "root_id": graph.root_id,
                "source_path": graph.source_path,
            }
            for node in graph.nodes
        ],
        "nodeset_types": [
            {
                "type_key": nodeset.type_key,
                "expand": nodeset.expand,
                "display_name": nodeset.display_name,
                "description": nodeset.description,
                "requires": requirements_to_dicts(nodeset.requires),
                "provides": providers_to_dicts(nodeset.provides),
                "status": nodeset.status,
                "planned_behavior": nodeset.planned_behavior.to_dict(),
                "node_count": len(nodeset.graph.nodes),
                "root_id": nodeset.root_id,
                "root_path": nodeset.root_path,
                "source_path": nodeset.source_path,
            }
            for nodeset in graph.nodeset_types.values()
        ],
        "nodeset_imports": [dict(item) for item in document.nodeset_imports],
        "resources": resources.to_dict(),
        "max_steps": graph.max_steps,
        "effective_edges": [{"from": edge.source, "to": edge.target, "when": edge.when} for edge in compiled.effective_edges],
    }
    return payload, 0


def _load_initial_input(path: Path) -> dict[str, object]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("--input JSON root must be an object")
    return {str(key): value for key, value in payload.items()}


def _removed_async_flush_timeout(value):
    raise argparse.ArgumentTypeError("GRAPH.ASYNC.MIGRATION: async flush timeout was removed; workflow waits for actual cleanup")


def _add_runtime_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--async-flush-timeout", type=_removed_async_flush_timeout, help=argparse.SUPPRESS)
    parser.add_argument("--status-interval", type=_positive_finite_float, default=None,
                        help="seconds between status.json heartbeats (default: 60)")
    parser.add_argument("--status-file", default=None, help="fixed monitor JSON path (default: run_dir/status.json)")
    parser.add_argument("--runtime-profile", choices=("debug", "train"), default=None, help="runtime option preset")
    parser.add_argument("--trace", choices=("full", "boundary", "off"), default=None, help="runtime trace policy")
    parser.add_argument("--execution", choices=("plan", "block", "compiled"), default=None, help="runtime execution mode")
    parser.add_argument("--run-hooks", action=argparse.BooleanOptionalAction, default=None, help="enable or disable run-level runtime plugin hooks")
    parser.add_argument("--node-hooks", action=argparse.BooleanOptionalAction, default=None, help="enable or disable node-level runtime plugin hooks")
    parser.add_argument("--nodeset-hooks", action=argparse.BooleanOptionalAction, default=None, help="enable or disable nodeset-level runtime plugin hooks")
    parser.add_argument("--block-hooks", action=argparse.BooleanOptionalAction, default=None, help="enable or disable block-level runtime plugin hooks")
    parser.add_argument("--allow-planned-stub", action="store_true", help="development only: execute planned python_stub nodes")


def _positive_finite_float(value: str) -> float:
    parsed = _non_negative_finite_float(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive finite seconds")
    return parsed


def _non_negative_finite_float(value: str) -> float:
    try:
        parsed = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("must be a non-negative finite number") from exc
    if not math.isfinite(parsed) or parsed < 0:
        raise argparse.ArgumentTypeError("must be a non-negative finite number")
    return parsed


def _runtime_options_from_args(args: argparse.Namespace):
    values: dict[str, object] = {}
    if getattr(args, "status_interval", None) is not None:
        values["status_interval"] = args.status_interval
    if getattr(args, "status_file", None) is not None:
        values["status_file"] = args.status_file
    if args.runtime_profile == "train":
        values.update(
            {
                "trace": "boundary",
                "run_hooks": True,
                "node_hooks": False,
                "nodeset_hooks": False,
                "block_hooks": True,
                "execution": "compiled",
            }
        )
    elif args.runtime_profile == "debug":
        values.update({"trace": "full", "run_hooks": True, "node_hooks": True, "nodeset_hooks": True, "block_hooks": True, "execution": "plan"})
    if args.trace is not None:
        values["trace"] = args.trace
    if args.execution is not None:
        values["execution"] = args.execution
    if args.run_hooks is not None:
        values["run_hooks"] = args.run_hooks
    if args.node_hooks is not None:
        values["node_hooks"] = args.node_hooks
    if args.nodeset_hooks is not None:
        values["nodeset_hooks"] = args.nodeset_hooks
    if args.block_hooks is not None:
        values["block_hooks"] = args.block_hooks
    if args.allow_planned_stub:
        values["allow_planned_stub"] = True
    return values


__all__ = ["build_parser", "main"]


def _handle_build(args):
    from vibeflow.tooling.application.python.cli.build import handle_build
    return handle_build(args)
